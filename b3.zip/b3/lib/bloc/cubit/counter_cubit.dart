

import 'package:bloc/bloc.dart';

class CounterCubit extends Cubit<int>{
  CounterCubit():super(0); // State Initalize with  0 value 

  void plus(){
     emit(state + 1);
  }
  void minus(){
    emit(state-1);
  }
  
}

void main(){
  CounterCubit c = CounterCubit();
  c.stream.listen((data)=>print("Data Rec $data"),
  onError: (err)=>print("erro rec $err"), onDone: ()=>print("Done"));
  c.plus();
  c.plus();
  c.plus();
  c.minus();
  c.close();
  // print(c.state); //0
  // c.plus(); 
  // print(c.state);
  // c.plus();
  // print(c.state);
  // c.minus();
  // print(c.state);
  c.close();
}
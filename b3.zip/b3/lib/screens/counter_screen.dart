import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:statedemo/bloc/counter_bloc.dart';

class CounterScreen extends StatelessWidget {
  late BuildContext ctx;
  plus() {
    CounterBloc bloc = BlocProvider.of<CounterBloc>(ctx);
    bloc.add(PlusEvent());
  }

  minus() {
    CounterBloc bloc = BlocProvider.of<CounterBloc>(ctx);
    bloc.add(MinusEvent());
  }

  @override
  Widget build(BuildContext context) {
    this.ctx = context;
    return Scaffold(
      appBar: AppBar(
        title: Text('Bloc Counter App'),
      ),
      body: Column(
        children: [
          BlocBuilder<CounterBloc, CounterState>(
            // buildWhen: (prevState, currentState) {
            //   print("State Change $prevState and $currentState");
            //   return true;
            // },
            builder: (ctx, state) {
              print("BUILDER ::::::: State is $state");
              return Text('Count is ${state.x} and ${state.y}',
                  style: TextStyle(fontSize: 30));
            },
          ),
          Row(
            children: [
              SizedBox(width: 10),
              ElevatedButton(
                  onPressed: () {
                    plus();
                  },
                  child: Text('+')),
              SizedBox(width: 10),
              ElevatedButton(
                  onPressed: () {
                    minus();
                  },
                  child: Text('-'))
            ],
          )
        ],
      ),
    );
  }
}

class Person {
  final String name;
  final int id;
  //final int age;
  // const constructor - all the members are final and object never be change
  const Person(this.id, this.name);
}

void main() {
  Person person = const Person(1001, "Amit");
  Person person2 = const Person(1001, "Amit");
  Person person3 = const Person(1001, "Amit");
  print(person);
  print(person2);
  print(person3);
  print(identical(person, person2));
  print(person == person3);
}

class Emp {
  late int id;
  late String name;
  late double salary;
  Emp.formatCons(int id, String name, double salary) {
    this.id = id;
    this.name = name.toUpperCase();
    this.salary = salary + salary * 0.20;
  }
  Emp(int id, String name, double salary) : this.formatCons(id, name, salary);

  @override
  String toString() => 'Emp(id: $id, name: $name, salary: $salary)';
}

void main() {
  Emp emp = new Emp(1001, "ram", 9000);
  print(emp);
}

//BluePrint
class Employee {
  // public instance variables
  // _ private (With in File)
  late int
      _id; // When they come in a memory , when object is get created or instance is created
  // that's why these are called instance variables
  late String _name;
  late double _salary;
  late String _companyName;
  late int age; // comes later on surely
  String? city; // might be null
  late String phone;
  late String manager;

  get name => this._name;

  set name(value) => this._name = value;

  get companyName => this._companyName;

  set companyName(value) => this._companyName = value;

  get getAge => this.age;

  set setAge(age) => this.age = age;

  get getCity => this.city;

  set setCity(city) => this.city = city;

  get getPhone => this.phone;

  set setPhone(phone) => this.phone = phone;

  get getManager => this.manager;

  set setManager(manager) => this.manager = manager;
  // every class by default has default constructor
  // it does nothing
  // Employee() {
  //   print("I am a Default Constructor of an Employee");
  //   _id = 1001;
  //   _name = "Amit";
  //   _salary = 9999;
  //   _companyName = "Brain Mentors";
  // }
  // constructor shorthand
  // Employee(this._id, this._name, this._salary, this._companyName);
  Employee(
      {required int id,
      required String name,
      required double salary,
      String companyName = "Brain Mentors"})
      : this._id = id,
        this._name = name,
        this._salary = salary;
  /*Employee(
      {required int id,
      required String name,
      required double salary,
      String companyName = "Brain Mentors"}) {
    this._id = id;
    this._name = name;
    this._salary = salary;
    _companyName = companyName;
  }*/
  // Named Constructor
  Employee.takeInput(this._id, this._name, this._salary);
  // Employee.takeInput(int id, String name) {
  //   this._id = id;
  //   this._name = name;
  // }
  /*void takeInput(int id, String name, double salary, String companyName) {
    if (id < 0 || salary < 0) {
      print("Invalid Id or Salary ");
      return;
    }
    this._id = id;
    this._name = name;
    this._salary = salary;
    this._companyName = companyName;
  }*/

  set salary(double salary) => this._salary = salary;
  double get salary => this._salary;

  void printDetails() {
    print("Id ${this._id}");
    print("Name $_name");
    print("Salary $_salary");
    print("Name $_companyName");
    print("*************************************");
  }
}

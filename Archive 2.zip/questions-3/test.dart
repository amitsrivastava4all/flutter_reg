import 'customer.dart';
import 'address.dart';
import 'order.dart';
import 'product.dart';

void main() {
  var customerMap = <int, Customer>{}; // JS Style
  //Map<int, Customer> customerMap = {}; // Java Style
  var amit = Customer(id: 1001, name: "Amit", balance: 9999, phone: "22222");
  // Customer amit =
  //     new Customer(id: 1001, name: "Amit", balance: 9999, phone: "22222");
  customerMap.putIfAbsent(amit.id, () => amit);
  //Map<String, Set<Address>> officeMap = {};
  Address address1 = new Address("Delhi", "India");
  Address address2 = new Address("Delhi", "India");
  Address address3 = new Address("Mumbai", "India");
  Set<Address> addressSet = {address1, address2, address3};
  amit.addressMap.putIfAbsent("office", () => addressSet);

  Map<int, Order> orderMap = {};

  var products = <Product>[
    Product(id: 90, name: "Samsung Mobile", price: 90000),
    Product(id: 100, name: "Apple Mobile", price: 90000)
  ];
  // List<Product> products = [
  //   Product(id: 90, name: "Samsung Mobile", price: 90000),
  //   Product(id: 100, name: "Apple Mobile", price: 90000)
  // ];
  Order order = new Order(id: 1, name: "MyOrder", products: products);
  orderMap.putIfAbsent(order.id, () => order);
  amit.orderMap = orderMap;
  print(amit);
}

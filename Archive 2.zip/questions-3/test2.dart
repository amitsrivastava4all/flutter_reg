import '../now-oops/employee.dart';

class Student extends Object {
  int rollno;
  String name;
  Student(this.rollno, this.name);
  @override
  bool operator ==(Object other) {
    if (other == null) {
      return false;
    }
    if (other is! Student) {
      return false;
    }
    Student student = other as Student;
    if (this.rollno == student.rollno && this.name == student.name) {
      return true;
    } else {
      return false;
    }
  }

  @override
  int get hashCode {
    return name.length;
  }

  @override
  String toString() {
    return "Rollno $rollno Name $name";
  }
}

void main() {
  Set<String> songs = {"Bang Bang", "Boom Boom", "Bang Bang", "Boom Boom"};
  print(songs);
  Student manish = Student(1002, "manish");
  //print(manish.toString()); // manish.toString()
  Set<Student> students = {
    Student(1001, "Amit"),
    manish,
    Student(1001, "Amit")
  };

  print(students);
}

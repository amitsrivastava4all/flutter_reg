class Address {
  String _city;
  String _country;
  Address(this._city, this._country);
  String get country => this._country;

  @override
  int get hashCode {
    return _city.length;
  }

  @override
  bool operator ==(Object other) {
    if (other == null) {
      return false;
    }
    if (other is! Address) {
      return false;
    }
    Address address = other as Address;
    if (this._city == address._city && this._country == address._country) {
      return true;
    } else {
      return false;
    }
  }

  set country(String value) => this._country = value;

  get city => this._city;

  set city(value) => this._city = value;

  String toString() {
    return "City $city Country $country";
  }
}

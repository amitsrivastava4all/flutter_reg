import 'order.dart';
import 'address.dart';

class Customer {
  int _id;
  String _name;
  double _balance;
  Map<String, Set<Address>> _addressMap = {};
  Map<int, Order> _orderMap = {};
  Map<String, Set<Address>> get addressMap => this._addressMap;

  set addressMap(Map<String, Set<Address>> addressMap) =>
      this._addressMap = addressMap;

  Map<int, Order> get orderMap => this._orderMap;

  set orderMap(Map<int, Order> orderMap) => this._orderMap = orderMap;

  String _phone;
  get id => this._id;

  get name => this._name;

  set name(value) => this._name = value;

  get balance => this._balance;

  set balance(value) => this._balance = value;

  get phone => this._phone;

  set phone(value) => this._phone = value;
  String toString() {
    return "Customer Id $id Name $name Balance $balance Address $_addressMap Order $orderMap";
  }

  Customer(
      {required int id,
      required String name,
      required double balance,
      required String phone})
      : this._id = id,
        this._name = name,
        this._balance = balance,
        this._phone = phone;
}

import 'package:firstapp/model/product.dart';

class ProductOperations {
  ProductOperations._init() {}
  static List<Product> fillProducts() {
    return [
      Product(
          'https://www.daawat.com/sites/all/themes/ltfoods/images/Biryani-Pack-Shot-Inside.png',
          'rice'),
      Product(
          'https://www.chingssecret.com/public/uploads/products/1581598043_13_pfi_Manchow-Soup2.png',
          'Soup'),
      Product(
          'https://www.bigbasket.com/media/uploads/p/xxl/70001176_4-english-oven-bread-pav.jpg',
          'Bread'),
      Product(
          'https://5.imimg.com/data5/SELLER/Default/2021/7/HQ/UL/EX/102391399/final-green-500x500.png',
          'Kiwi'),
      Product(
          'https://www.chingssecret.com/public/uploads/products/1581598043_13_pfi_Manchow-Soup2.png',
          'Veg Soup'),
      Product(
          'https://www.bigbasket.com/media/uploads/p/xxl/70001176_4-english-oven-bread-pav.jpg',
          'Brown Bread'),
      Product(
          'https://www.washfruit.com/wp-content/uploads/2020/03/allfruit.png',
          'All Fruit'),
      Product(
          'https://www.chingssecret.com/public/uploads/products/1581598043_13_pfi_Manchow-Soup2.png',
          'Veg Soup'),
      Product(
          'https://www.bigbasket.com/media/uploads/p/xxl/70001176_4-english-oven-bread-pav.jpg',
          'Brown Bread'),
      Product(
          'https://5.imimg.com/data5/SELLER/Default/2021/7/HQ/UL/EX/102391399/final-green-500x500.png',
          'Kiwi Fruit'),
      Product(
          'https://www.chingssecret.com/public/uploads/products/1581598043_13_pfi_Manchow-Soup2.png',
          'Veg Soup'),
      Product(
          'https://www.bigbasket.com/media/uploads/p/xxl/70001176_4-english-oven-bread-pav.jpg',
          'Brown Bread'),
      Product(
          'https://5.imimg.com/data5/SELLER/Default/2021/7/HQ/UL/EX/102391399/final-green-500x500.png',
          'Kiwi Fruit'),
      Product(
          'https://www.chingssecret.com/public/uploads/products/1581598043_13_pfi_Manchow-Soup2.png',
          'Veg Soup'),
      Product(
          'https://www.bigbasket.com/media/uploads/p/xxl/70001176_4-english-oven-bread-pav.jpg',
          'Brown Bread')
    ];
  }
}

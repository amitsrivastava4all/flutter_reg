import 'package:flutter/material.dart';

class BigImages extends StatelessWidget {
  const BigImages({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    const URL1 =
        'https://www.denofgeek.com/wp-content/uploads/2019/02/mcu-1-iron-man.jpg';
    const URL2 =
        'https://images.news18.com/ibnlive/uploads/2016/04/ironman.jpg';
    const URL3 =
        'https://imagesvc.meredithcorp.io/v3/mm/image?q=85&c=sc&poi=face&w=2000&h=1000&url=https%3A%2F%2Fstatic.onecms.io%2Fwp-content%2Fuploads%2Fsites%2F6%2F2018%2F01%2Fim2-fx-0740-2000.jpg';
    return Scaffold(
      body: SafeArea(
          child: Row(
        children: [
          Expanded(
            child: Image.network(URL1),
            flex: 2,
          ),
          Expanded(
            child: Image.network(URL2),
            flex: 1,
          ),
          Expanded(
            child: Image.network(URL3),
            flex: 3,
          )
        ],
      )),
    );
  }
}

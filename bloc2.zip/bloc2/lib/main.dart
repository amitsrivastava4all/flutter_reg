import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:task_manager_app/pages/login.dart';
import 'package:task_manager_app/pages/tasks.dart';
import 'package:task_manager_app/provider/task_provider.dart';

import 'domain/models/user.dart';
import 'pages/addtask.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp( ChangeNotifierProvider<TaskProvider>(
      create: (_)=>TaskProvider(),
      child: MaterialApp(
    //home: AddTask(),
    
   
      home: TaskList( User('nisha@yahoo.com','Nisha','https://preview.keenthemes.com/metronic-v4/theme/assets/pages/media/profile/profile_user.jpg'))),
  ));
}

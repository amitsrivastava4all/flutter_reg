
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Footer extends StatelessWidget {
  const Footer({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    
      return BottomAppBar(
        color: Colors.pinkAccent,
        child: Text('Powered by Brain Mentors', style: GoogleFonts.pacifico(fontSize: 20),),);
    
  }
}
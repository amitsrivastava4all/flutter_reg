




import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:task_manager_app/domain/models/task_items.dart';
import 'package:task_manager_app/domain/repository/task_operations.dart';
import 'package:task_manager_app/pages/edit_task.dart';
import 'package:task_manager_app/provider/task_provider.dart';

class Tasks extends StatelessWidget {
  
  Tasks({ Key? key }) : super(key: key);
  _getItems(){

    this.items =  [
      TaskItem('A', 'AAAA', '11:10AM'),
      TaskItem('B', 'AAAA', '11:10AM'),
      TaskItem('C', 'AAAA', '11:10AM'),
      TaskItem('D', 'AAAA', '11:10AM'),
      TaskItem('E', 'AAAA', '11:10AM'),
      TaskItem('F', 'AAAA', '11:10AM')
    ];
    return items;
  }
  _showTasks(AsyncSnapshot<QuerySnapshot> snapshot){
    List<TaskItem>? list = snapshot.data?.docs.map((e) => TaskItem(e['title'], e['desc'], e['time'])).toList();
    return ListView.builder(
      scrollDirection: Axis.horizontal,
      itemBuilder: (BuildContext ctx, int index){
      return Stack(children: [
        Container(
          margin: EdgeInsets.all(10),
          child: Column(children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
              Icon(Icons.assignment_turned_in_outlined),
              Text(list![index].title)
            ],),
            SizedBox(height: 10,),
            Text(list[index].desc, style: GoogleFonts.roboto(fontSize:20,))
          ],),
          decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(color: Colors.white, spreadRadius: 2)
          ],  
          color: Colors.amberAccent,
          borderRadius: BorderRadius.only(topLeft: Radius.circular(50), bottomRight: Radius.circular(50))
          
        ),
        height: 250,
        width:250
        ),
        Positioned(child: _editButton(list[index].title, list[index].desc, ctx), right: 0, top:0)
      ],);
    },itemCount: list?.length,);
  }
  List<TaskItem> items = [];
  
    shareThisData(String title, String desc, ctx){
      TaskProvider tp = Provider.of<TaskProvider>(ctx,listen:false);
        tp.shareThisData(title, desc);
        Navigator.of(ctx).push(MaterialPageRoute(builder: (_)=>EditTask()));
    }

  _editButton(String title, String desc, ctx){
    return Container(
      decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.redAccent),
      child: IconButton(onPressed: (){
        print("Edit Button Clicked $title $desc");
        //TaskProvider tp = TaskProvider();
        shareThisData(title, desc, ctx);

      },icon:Icon(Icons.mode_edit_sharp)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
     // color: Colors.blue,
      height: 250,
      child: StreamBuilder(stream: TaskOperations.readAllTask(),
      builder: (BuildContext ctx, AsyncSnapshot<QuerySnapshot> snapShot){
        
        if(snapShot.hasError){
          return Text('Some Error During FireBase call');
        }
        else
        if(!snapShot.hasData){
          return Center(child: CircularProgressIndicator(),);
        }
        //(snapShot.hasData){
          else{
          return _showTasks(snapShot);
        }
      },
      )
    );
  }
}
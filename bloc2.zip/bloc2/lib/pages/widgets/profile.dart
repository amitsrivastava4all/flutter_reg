
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:task_manager_app/domain/models/user.dart';

class Profile extends StatelessWidget {
  
  //const Profile({ Key? key }) : super(key: key);
  User? user;
  Profile(this.user);
  @override
  Widget build(BuildContext context) {
    //const url = 'https://preview.keenthemes.com/metronic-v4/theme/assets/pages/media/profile/profile_user.jpg';
    var url = user?.photo;
    url??='https://preview.keenthemes.com/metronic-v4/theme/assets/pages/media/profile/profile_user.jpg';
    var email = user?.email;
    email??="";
    return Container(
      child: Column(children: [
        Container(
          height: 150,
          width: 150,
          
          decoration:  BoxDecoration(
            border:  Border.all(width: 2, color: Colors.blue),
            shape: BoxShape.circle,
            image: 
           DecorationImage(
            fit:BoxFit.fill,
            image: NetworkImage(url),)),
        ),
        Text(email.toString(), style: GoogleFonts.meriendaOne(color:Colors.black, fontSize: 18),),
        Text('Here are Your Today Tasks', style: GoogleFonts.roboto(fontSize:16 ))
      ],),
    );
  }
}
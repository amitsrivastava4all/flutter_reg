import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Header extends StatelessWidget {
  const Header({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
        IconButton(onPressed: (){}, icon: Icon(Icons.menu)),
        Text("Today Tasks", style: GoogleFonts.pacifico(fontSize: 20),),
        IconButton(onPressed: (){}, icon: Icon(Icons.search))
      ],),
    );
  }
}
void main(){
  Stream<int> stream = doingStreaming();
  stream.listen((event) { 
    print("Data Rec $event");
  });
}

Stream<int> doingStreaming() async*{ 
  for(int i = 1; i<=10; i++){
    print("Data Going to  Send $i");
    await Future.delayed(Duration(seconds: 3));
    yield i;
  }
}
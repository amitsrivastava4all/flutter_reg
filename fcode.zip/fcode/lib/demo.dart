import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Text('Hello Flutter'),
  ));
}

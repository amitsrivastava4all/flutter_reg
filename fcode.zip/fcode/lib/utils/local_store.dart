import 'package:chatapp/domain/models/user_model.dart';
import 'package:chatapp/utils/adapters/user_adapter.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';

Future<UserModel> loadLocalData() async {
  var dir = await getApplicationDocumentsDirectory();
  Hive.init(dir.path);
  await Hive.openBox("user-box");
  var box = Hive.box('user-box');
  var user =
      UserAdapter.takeInput('amit@gmail.com', '999999', 'Amit Srivastava');

  box.add(user);
  user.save();
  box.put('user', user);
  return box.get('user');
}

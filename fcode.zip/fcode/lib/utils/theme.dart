import 'package:chatapp/utils/constants.dart';
import 'package:flutter/material.dart';

ThemeData getTheme(BuildContext context) {
  return ThemeData(
    primaryColor: Constants.WHATS_APP_GREEN_COLOR,
    backgroundColor: Constants.WHATS_APP_GREEN_COLOR,
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
          elevation: 5,
          shadowColor: Colors.black,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
    ),
  );
}

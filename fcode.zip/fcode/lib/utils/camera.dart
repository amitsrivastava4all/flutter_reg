import 'package:chatapp/domain/controllers/image.dart';
import 'package:image_picker/image_picker.dart';
import 'package:get/get.dart';

class Camera {
  final ImagePicker _picker = ImagePicker();
  ImageController imageCtrl = Get.put(ImageController());
  Future<XFile?> pickImage() async {
    final XFile? photo = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 50,
        preferredCameraDevice: CameraDevice.front);
    String? path = photo?.path;
    imageCtrl.photo.value = path.toString(); // Setting Image Path in Getx State
    return photo;
  }
}

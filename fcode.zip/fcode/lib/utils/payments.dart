import 'package:razorpay_flutter/razorpay_flutter.dart';

payUsingRazorPay() {
  var options = {
    'key': 'rzp_test_pHyplZnxGWeSQD',
    'amount': 100,
    'name': 'BM.',
    'description': 'Java DSA Course',
    'prefill': {'contact': '8888888888', 'email': 'test@razorpay.com'}
  };
  var _razorpay = Razorpay();
  _razorpay.open(options);

  _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS,
      (PaymentSuccessResponse response) {
    print("Payment Done.... $response");
    print(response.paymentId);
    print(response.orderId);
    print(response.signature);
  });
  _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, (PaymentFailureResponse response) {
    print("Payment Fail.... $response");
  });
  _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET,
      (ExternalWalletResponse response) {
    print("Payment Via Wallet.... $response");
  });
}

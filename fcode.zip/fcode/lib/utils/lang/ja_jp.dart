const Map<String, String> jaJP = {'register': "ここに登録", 'login': "ログインする"};

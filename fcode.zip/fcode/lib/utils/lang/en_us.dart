const Map<String, String> enUS = {'register': "Register ", 'login': "Login"};

const Map<String, String> hiIN = {
  'register': "यहां रजिस्टर करें",
  'login': "लॉग इन करें"
};

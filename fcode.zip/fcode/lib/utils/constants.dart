import 'package:flutter/material.dart';

class Constants {
  static final String HOME = "/";
  static final String CHATS = "/chats";
  static final Color WHATS_APP_GREEN_COLOR = Color.fromRGBO(18, 140, 126, 1.0);
}

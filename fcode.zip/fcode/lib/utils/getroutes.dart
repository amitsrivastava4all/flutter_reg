import 'package:chatapp/screens/chats.dart';
import 'package:chatapp/screens/splash.dart';
import 'package:chatapp/utils/constants.dart';

// All the Application routes are placed here
getRoutes() {
  return {
    Constants.HOME: (context) => const Splash(),
    Constants.CHATS: (context) => Chats()
  };
}

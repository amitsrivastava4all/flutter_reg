import 'package:hive/hive.dart';

@HiveType(typeId: 0)
class UserAdapter extends HiveObject {
  @HiveField(0)
  late String email;
  @HiveField(1)
  late String password;
  @HiveField(2)
  late String name;
  UserAdapter() {}
  UserAdapter.takeInput(this.email, this.password, this.name);
}

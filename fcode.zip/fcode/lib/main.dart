import 'package:chatapp/screens/splash.dart';
import 'package:chatapp/screens/widgets/login.dart';
import 'package:chatapp/screens/user.dart';
import 'package:chatapp/utils/adapters/user_adapter.dart';
import 'package:chatapp/utils/constants.dart';
import 'package:chatapp/utils/getroutes.dart';
import 'package:chatapp/utils/theme.dart';
import 'package:chatapp/utils/translation_service.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:hive_flutter/hive_flutter.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: ".env"); // to read the env file
  final appDocumentDir = await getApplicationDocumentsDirectory();
  await Hive.initFlutter();
  //Hive.registerAdapter(TodoAdapter()); // run at command line pub run build_runner build
  // flutter packages pub run build_runner build
  await Firebase.initializeApp();
  runApp(App());
}

class App extends StatelessWidget {
  const App({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      locale: LocalizationService.defaultLocale,
      fallbackLocale: LocalizationService.fallbackLocale,
      translations: LocalizationService(),
      routes: getRoutes(), // Loading all the routes
      initialRoute: Constants.HOME, // Which one is the inital route
      theme: getTheme(context),
    );
  }
}

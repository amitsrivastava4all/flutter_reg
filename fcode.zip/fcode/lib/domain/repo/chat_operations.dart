import 'package:chatapp/domain/models/chat_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ChatOperations {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  static final CollectionReference chats = _firestore.collection('chats');
  Stream<List<ChatModel>> getChats() {
    Stream<QuerySnapshot> stream =
        chats.orderBy('datetime', descending: true).snapshots();
    return stream.map((event) => event.docs.map((doc) {
          var m = doc.data();
          print(
              "M is $m and m is ${m.runtimeType} }"); // gives internallinkedhashmap
          var map = m as Map;
          print("Map is $map and map is title ${map['text']} }");
          ChatModel chatModel = ChatModel();
          chatModel.text = map['text'];
          chatModel.userName = map['name'];
          chatModel.dateTime = map['datetime'].toString();
          return chatModel;
        }).toList());
  }

  addNewMessage(ChatModel chatModel) async {
    try {
      await chats.add({
        'name': chatModel.userName,
        'text': chatModel.text,
        'datetime': Timestamp.now()
      });
      return "Message Added";
    } on FirebaseAuthException catch (e) {
      return e.message.toString();
    }
  }
}

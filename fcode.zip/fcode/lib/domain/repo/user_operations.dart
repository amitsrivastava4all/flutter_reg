import 'dart:io';

import 'package:chatapp/domain/models/user_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class UserOperations {
  //static final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  //UserOperations._() {}
  Future<String> login(UserModel userModel) async {
    try {
      await _auth.signInWithEmailAndPassword(
          email: userModel.email.toString(),
          password: userModel.password.toString());
      return "Login SuccessFully";
    } on FirebaseAuthException catch (e) {
      return e.message.toString();
    }
  }

  Future<String> uploadImage(
    File imageFile,
  ) async {
    String? uid = _auth.currentUser?.uid;
    Reference ref = FirebaseStorage.instance
        .ref()
        .child('userphoto')
        .child("${uid.toString()}.jpg");
    await ref.putFile(imageFile);
    String url = await ref.getDownloadURL();
    return url;
  }

  Future<String?> getUserNameById(String uid) async {
    try {
      String userCollection = dotenv.env['USER_COLLECTION'].toString();
      DocumentSnapshot doc = await FirebaseFirestore.instance
          .collection(userCollection)
          .doc(uid)
          .get();
      print("Get User Name by id $doc and UID is $uid");
      return doc['name'];
    } catch (err) {
      print("Error While Fetching Name $err");
    }
    return null;
  }

  String? getCurrentUser() {
    return _auth.currentUser?.uid;
  }

  Future<String> register(UserModel userModel) async {
    try {
      String userCollection = dotenv.env['USER_COLLECTION'].toString();
      UserCredential cred = await _auth.createUserWithEmailAndPassword(
          email: userModel.email.toString(),
          password: userModel.password.toString());
      await FirebaseFirestore.instance
          .collection(userCollection)
          .doc(cred.user?.uid)
          .set({
        'name': userModel.name,
        'email': userModel.email,
        'imageurl': userModel.imageURL
      });
      return "Register Successfully ";
    } on FirebaseAuthException catch (e) {
      return e.message.toString();
    }
  }
}

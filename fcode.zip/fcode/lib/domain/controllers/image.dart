import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:image_picker/image_picker.dart';

class ImageController extends GetxController {
  var photo = "".obs;
  var isUploaded = false.obs;
}

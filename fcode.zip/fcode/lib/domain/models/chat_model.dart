class ChatModel {
  String? text;
  String? userName;
  String? dateTime;

  String? get getText => this.text;

  set setText(String? text) => this.text = text;

  get getUserName => this.userName;

  set setUserName(userName) => this.userName = userName;

  get getDateTime => this.dateTime;

  set setDateTime(dateTime) => this.dateTime = dateTime;

  @override
  String toString() =>
      'ChatModel(text: $text, userName: $userName, dateTime: $dateTime)';
}

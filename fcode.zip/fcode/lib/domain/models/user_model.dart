class UserModel {
  String? email;
  String? name;
  String? password;
  String? imageURL;
  String? get getImageURL => this.imageURL;

  set setImageURL(String? imageURL) => this.imageURL = imageURL;

  String? get getEmail => this.email;

  set setEmail(String email) => this.email = email;

  get getName => this.name;

  set setName(name) => this.name = name;

  get getPassword => this.password;

  set setPassword(password) => this.password = password;

  Map<String, dynamic> toJson() =>
      {'email': email, 'password': password, 'name': name};

  @override
  String toString() =>
      'UserModel(email: $email, name: $name, password: $password)';
}

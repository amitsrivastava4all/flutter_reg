import 'dart:async';

import 'package:chatapp/domain/models/user_model.dart';
import 'package:chatapp/screens/widgets/login.dart';
import 'package:chatapp/screens/widgets/register.dart';
import 'package:chatapp/utils/local_store.dart';
import 'package:chatapp/utils/translation_service.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'widgets/snackbar.dart';

class User extends StatefulWidget {
  const User({Key? key}) : super(key: key);

  @override
  _UserState createState() => _UserState();
}

class _UserState extends State<User> {
  int _selectedIndex = 0;
  List<Widget> userScreens = [Login(), Register()];
  String _selectedLang = LocalizationService.langs.first;
  _showLangDropDown() {
    return DropdownButton(
      icon: Icon(Icons.arrow_drop_down),
      value: _selectedLang,
      items: LocalizationService.langs.map((String lang) {
        return DropdownMenuItem(value: lang, child: Text(lang));
      }).toList(),
      onChanged: (String? value) {
        // updates dropdown selected value
        setState(() => _selectedLang = value!);
        // gets language and changes the locale
        LocalizationService().changeLocale(value!);
      },
    );
  }

  late StreamSubscription<ConnectivityResult> _subscription;
  bool isLocal = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _subscription = Connectivity()
        .onConnectivityChanged
        .listen((ConnectivityResult result) async {
      if (result == ConnectivityResult.mobile) {
        showSnackBar('Mobile Data Connected');
      } else if (result == ConnectivityResult.wifi) {
        showSnackBar('Wifi  Connected');
      } else {
        isLocal = true;
        UserModel model = await loadLocalData();
        print("UserModel is $model");
        showSnackBar('No Wifi/Mobile Data Connected');
      }
      // Got a new connectivity status!
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).backgroundColor,
      appBar: AppBar(
        title: _showLangDropDown(),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.black,
        unselectedItemColor: Colors.white,
        selectedItemColor: Colors.yellowAccent,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.login),
            label: 'login'.tr,
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.app_registration),
            label: 'register'.tr,
          )
        ],
        currentIndex: _selectedIndex,
        onTap: (int index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
      body: userScreens[_selectedIndex],
    );
  }
}

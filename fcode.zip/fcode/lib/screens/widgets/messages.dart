import 'package:chatapp/domain/models/chat_model.dart';
import 'package:chatapp/domain/repo/chat_operations.dart';
import 'package:chatapp/screens/widgets/message.dart';
import 'package:flutter/material.dart';
import 'package:get/instance_manager.dart';
import 'package:google_fonts/google_fonts.dart';

class Messages extends StatelessWidget {
  ChatOperations opr = Get.put(ChatOperations());
  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      builder: (BuildContext ctx, AsyncSnapshot<List<ChatModel>> snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(
            child: CircularProgressIndicator(),
          );
        } else if (snapshot.hasError) {
          return Center(
              child: Text('Some Error During Chat Messages',
                  style: GoogleFonts.pacifico()));
        } else if (!snapshot.hasData) {
          return Center(
              child: Text('No Message', style: GoogleFonts.pacifico()));
        }
        return ListView.builder(
          itemBuilder: (_, int index) {
            print("DATA ${snapshot.data![index]}");
            ChatModel chat = snapshot.data![index];
            return Message(chat);
          },
          itemCount: snapshot.data?.length,
          reverse: true, // start from the bottom
        );
      },
      stream: opr.getChats(),
    );
  }
}

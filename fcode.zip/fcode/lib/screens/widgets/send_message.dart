import 'package:chatapp/domain/models/chat_model.dart';
import 'package:chatapp/domain/repo/chat_operations.dart';
import 'package:chatapp/domain/repo/user_operations.dart';
import 'package:chatapp/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SendMessage extends StatelessWidget {
  String _message = "";
  ChatOperations chatOpr = Get.put(ChatOperations());
  UserOperations userOpr = Get.put(UserOperations());
  late BuildContext context;
  sendIt() async {
    FocusScope.of(context).unfocus();
    _message = tc.text;
    print("Message Send $_message");
    ChatModel chatModel = ChatModel();
    chatModel.text = _message;
    chatModel.userName = userOpr.getCurrentUser();

    String result = await chatOpr.addNewMessage(chatModel);
    Get.snackbar('Brain Mentors', result);
    tc.clear();
  }

  TextEditingController tc = TextEditingController();
  @override
  Widget build(BuildContext context) {
    this.context = context;
    return Container(
      child: Row(
        children: [
          Expanded(
            child: Container(
              margin: EdgeInsets.all(10),
              child: TextField(
                controller: tc,
                decoration: InputDecoration(
                    prefixIcon: Icon(
                      Icons.emoji_emotions,
                      color: Constants.WHATS_APP_GREEN_COLOR,
                    ),
                    hintText: 'Type a Message',
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10))),
              ),
            ),
          ),
          IconButton(
              onPressed: () {
                sendIt();
              },
              icon: Icon(
                Icons.send,
                color: Constants.WHATS_APP_GREEN_COLOR,
              ))
        ],
      ),
    );
  }
}

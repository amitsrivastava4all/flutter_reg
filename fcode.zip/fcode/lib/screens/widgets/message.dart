// Represent a Single Message
import 'package:chatapp/domain/models/chat_model.dart';
import 'package:chatapp/domain/repo/user_operations.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Message extends StatefulWidget {
  ChatModel chatModel;
  Message(this.chatModel);
  @override
  _MessageState createState() => _MessageState();
}

class _MessageState extends State<Message> {
  UserOperations userOpr = Get.put(UserOperations());
  String? name;
  bool isIam = false;

  @override
  initState() {
    super.initState();
    getUserName();
    if (userOpr.getCurrentUser() == widget.chatModel.userName) {
      isIam = true;
    } else {
      isIam = false;
    }
    setState(() {});
  }

  getUserName() async {
    name =
        await userOpr.getUserNameById(widget.chatModel.userName.toString()) ??
            "";
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    Size deviceSize = MediaQuery.of(context).size;
    return Row(
      mainAxisAlignment:
          isIam ? MainAxisAlignment.end : MainAxisAlignment.start,
      children: [
        Container(
          padding: EdgeInsets.all(15),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Column(
                children: [
                  Text(
                    name.toString(),
                    style: TextStyle(color: Colors.redAccent),
                  ),
                  Text(
                    widget.chatModel.text.toString(),
                    style: TextStyle(fontSize: 14),
                  )
                ],
              ),
            ],
          ),
          width: deviceSize.width / 2,
          margin: EdgeInsets.all(10),
          decoration: BoxDecoration(
              color: isIam ? Colors.amber : Colors.lightGreen,
              borderRadius: BorderRadius.circular(10)),
        )
      ],
    );
  }
}

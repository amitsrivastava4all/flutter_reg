import 'dart:io';

import 'package:chatapp/domain/controllers/image.dart';
import 'package:chatapp/domain/models/user_model.dart';
import 'package:chatapp/domain/repo/user_operations.dart';
import 'package:chatapp/utils/camera.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

class Register extends StatelessWidget {
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  UserOperations opr = Get.put(UserOperations());
  UserModel? _userModel;
  Camera _camera = Camera();
  late BuildContext context;
  ImageController _imageController = Get.put(ImageController());

  _doRegister() async {
    var formState = _formKey.currentState;
    bool? isValid = formState?.validate();
    FocusScope.of(context)
        .unfocus(); // unfocus the keyboard during submission time
    if (isValid! && isValid) {
      _userModel = UserModel();
      formState?.save();
      // Upload the Image
      String imageURL = await opr.uploadImage(fileImage!.file);
      _userModel?.imageURL = imageURL;
      // Calling Reg Repo
      String result = await opr.register(_userModel!);
      final snackBar = SnackBar(content: Text(result));
      print("Result is $result");
      ScaffoldMessenger.of(context).showSnackBar(snackBar);
    }
  }

  FileImage? fileImage = null;
  @override
  Widget build(BuildContext context) {
    this.context = context;

    return Container(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Register',
              style: GoogleFonts.pacifico(fontSize: 30, color: Colors.black),
            ),
            Card(
              margin: EdgeInsets.all(20),
              elevation: 10,
              shadowColor: Colors.black,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      Obx(() {
                        String path = "";
                        if (_imageController.photo == "") {
                          path = "";
                        } else {
                          fileImage =
                              FileImage(File(_imageController.photo.value));
                        }
                        return CircleAvatar(
                            radius: 50,
                            backgroundColor: Colors.yellowAccent,
                            backgroundImage: fileImage);
                      }),
                      ElevatedButton(
                          style: ButtonStyle(
                              backgroundColor: MaterialStateProperty.all<Color>(
                                  Colors.redAccent)),
                          onPressed: () {
                            _camera.pickImage();
                          },
                          child: Icon(Icons.camera_alt_rounded)),
                      TextFormField(
                        onSaved: (String? value) {
                          _userModel?.email = value;
                        },
                        keyboardType: TextInputType.emailAddress,
                        decoration: const InputDecoration(labelText: 'Email'),
                        validator: (String? value) {
                          if (value != null) {
                            if (value.isEmpty || !value.contains('@')) {
                              return "Invalid Email Id";
                            }
                          }
                          return null;
                        },
                      ),
                      TextFormField(
                          onSaved: (String? value) {
                            _userModel?.name = value;
                          },
                          validator: (String? value) {
                            if (value != null) {
                              if (value.isEmpty || value.length < 3) {
                                return "Invalid Name";
                              }
                            }
                            return null;
                          },
                          decoration: const InputDecoration(labelText: 'Name')),
                      TextFormField(
                          onSaved: (String? value) {
                            _userModel?.password = value;
                          },
                          validator: (String? value) {
                            if (value != null) {
                              if (value.isEmpty || value.length < 5) {
                                return "Invalid Password";
                              }
                            }
                            return null;
                          },
                          obscureText: true,
                          decoration:
                              const InputDecoration(labelText: 'Password')),
                      Divider(
                        height: 10,
                      ),
                      ElevatedButton(
                          style: ButtonStyle(
                              backgroundColor: MaterialStateProperty.all<Color>(
                                  Theme.of(context).backgroundColor)),
                          onPressed: () {
                            _doRegister();
                          },
                          child: Text(
                            'Register',
                            style: GoogleFonts.pacifico(),
                          ))
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';

showSnackBar(String message) {
  Get.snackbar(
    "Brain Mentors App",
    message,
    colorText: Colors.black,
    backgroundColor: Colors.amberAccent,
    snackPosition: SnackPosition.BOTTOM,
    borderColor: Colors.indigo,
    borderRadius: 10,
    borderWidth: 2,
    barBlur: 2,
  );
}

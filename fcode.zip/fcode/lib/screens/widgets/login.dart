import 'dart:async';

import 'package:chatapp/domain/models/user_model.dart';
import 'package:chatapp/domain/repo/user_operations.dart';
import 'package:chatapp/screens/widgets/snackbar.dart';
import 'package:chatapp/utils/constants.dart';
import 'package:chatapp/utils/local_store.dart';
import 'package:chatapp/utils/payments.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

class Login extends StatelessWidget {
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  UserModel? _userModel;
  UserOperations opr = Get.put(UserOperations());
  late BuildContext context;

  _doLogin() async {
    var formState = _formKey.currentState;
    bool? isValid = formState?.validate();
    FocusScope.of(context)
        .unfocus(); // unfocus the keyboard during submission time
    if (isValid! && isValid) {
      _userModel = new UserModel();
      formState?.save();
      String result = await opr.login(_userModel!);
      if (result.contains("SuccessFully")) {
        Navigator.pushNamed(context, Constants.CHATS);
      }
      final snackBar = SnackBar(content: Text(result));
      print("Result is $result");
      ScaffoldMessenger.of(context).showSnackBar(snackBar);
    }
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;
    return Container(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Login',
              style: GoogleFonts.pacifico(fontSize: 30, color: Colors.white),
            ),
            Card(
              margin: EdgeInsets.all(20),
              elevation: 10,
              shadowColor: Colors.black,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      TextFormField(
                        onSaved: (String? value) {
                          _userModel?.email = value;
                        },
                        keyboardType: TextInputType.emailAddress,
                        decoration: const InputDecoration(labelText: 'Email'),
                        validator: (String? value) {
                          if (value != null) {
                            if (value.isEmpty || !value.contains('@')) {
                              return "Invalid Email Id";
                            }
                          }
                          return null;
                        },
                      ),
                      TextFormField(
                          onSaved: (String? value) {
                            _userModel?.password = value;
                          },
                          validator: (String? value) {
                            if (value != null) {
                              if (value.isEmpty || value.length < 5) {
                                return "Invalid Password";
                              }
                            }
                            return null;
                          },
                          obscureText: true,
                          decoration:
                              const InputDecoration(labelText: 'Password')),
                      Divider(
                        height: 10,
                      ),
                      ElevatedButton(
                          onPressed: () {
                            payUsingRazorPay();
                          },
                          child: Text('PayNow')),
                      ElevatedButton(
                          style: ButtonStyle(
                              backgroundColor: MaterialStateProperty.all<Color>(
                                  Theme.of(context).backgroundColor)),
                          onPressed: () {
                            _doLogin();
                          },
                          child: Text(
                            'Login',
                            style: GoogleFonts.pacifico(),
                          ))
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Show all the Chats
import 'package:chatapp/screens/widgets/messages.dart';
import 'package:chatapp/screens/widgets/send_message.dart';
import 'package:chatapp/utils/constants.dart';
import 'package:flutter/material.dart';

class Chats extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Chats",
          style: TextStyle(
              color: Colors.white, fontSize: 22.0, fontWeight: FontWeight.w600),
        ),
        actions: <Widget>[
          Padding(
            padding: const EdgeInsets.only(right: 20.0),
            child: Icon(Icons.search),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: Icon(Icons.more_vert),
          ),
        ],
        backgroundColor: Constants.WHATS_APP_GREEN_COLOR,
      ),
      body: Column(
        children: [Expanded(child: Messages()), SendMessage()],
      ),
      // floatingActionButton: FloatingActionButton(
      //   child: Icon(Icons.message_sharp),
      //   onPressed: () {},
      // ),
    );
  }
}

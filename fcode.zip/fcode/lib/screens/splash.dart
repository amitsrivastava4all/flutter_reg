import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:chatapp/screens/user.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Splash extends StatefulWidget {
  const Splash({Key? key}) : super(key: key);

  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  Widget build(BuildContext context) {
    return AnimatedSplashScreen(
      splash:
          '[n]https://blog.friday-ad.co.uk/wp-content/uploads/2020/05/90511037_111352067172676_3315258717179478016_n.jpg',
      nextScreen: const User(),
      splashTransition: SplashTransition.rotationTransition,
      backgroundColor: Colors.blueAccent,
      centered: true,
    );
  }
}

class User {
  String? email;
  String? name;
  String? photo;
  String? password;
  User.takeEmailAndPic(this.email, this.photo);
  User(this.email, this.name, this.photo);
  User.takeInput(this.email, this.password);

  
  @override
  String toString() {
    return "Email $email Name $name Photo $photo";
  }
}

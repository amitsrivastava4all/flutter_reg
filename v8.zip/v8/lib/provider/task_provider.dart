import 'package:flutter/material.dart';

class TaskProvider with ChangeNotifier{
  String? title;
  String? desc;
  void shareThisData(String title, String desc){
      this.title = title;
      this.desc  = desc;
      print("Data Shared.... ${this.title} and ${this.desc}");
      notifyListeners();
  }
}
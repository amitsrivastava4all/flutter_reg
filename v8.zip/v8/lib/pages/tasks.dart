
import 'package:flutter/material.dart';
import 'package:task_manager_app/domain/models/user.dart';
import 'package:task_manager_app/pages/widgets/date.dart';
import 'package:task_manager_app/pages/widgets/footer.dart';
import 'package:task_manager_app/pages/widgets/tasklist.dart';
import 'package:task_manager_app/pages/widgets/wave.dart';

class TaskList extends StatefulWidget {
  User? user;
  //const TaskList({ Key? key }) : super(key: key);
  TaskList(this.user);
  @override
  _TaskListState createState() => _TaskListState();
}

class _TaskListState extends State<TaskList> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Footer(),
      floatingActionButtonLocation: FloatingActionButtonLocation.endDocked,
      floatingActionButton: FloatingActionButton(onPressed: (){},backgroundColor: Colors.cyan, child:Icon(Icons.add)),
      backgroundColor:Colors.black,
      body:SafeArea(child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Wave(widget.user),
          DateWidget(),
          Tasks(),

          
      ],),)
    );
    // return Container(
    //   child:Center(child: Text('DashBoard',style: TextStyle(fontSize: 30),),)
    // );

  }
}
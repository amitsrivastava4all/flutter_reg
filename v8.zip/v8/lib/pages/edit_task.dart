import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:task_manager_app/domain/models/task_items.dart';
import 'package:task_manager_app/domain/repository/task_operations.dart';
import 'package:task_manager_app/provider/task_provider.dart';

class EditTask extends StatefulWidget {
  const EditTask({ Key? key }) : super(key: key);

  @override
  _EditTaskState createState() => _EditTaskState();
}

class _EditTaskState extends State<EditTask> {
  GlobalKey<FormState> formKey = GlobalKey<FormState>();
  String? name;
  String? desc;
  TextEditingController tc = TextEditingController();
  TextEditingController tc2 = TextEditingController();
  @override
  Widget build(BuildContext context) {
    TaskProvider tp = Provider.of<TaskProvider>(context);
    print(" ***************TP Rec ${tp.title} and ${tp.desc}");
    tc.text = tp.title.toString();
    tc2.text = tp.desc.toString();
    return Scaffold(
        appBar: AppBar(
          title: Text('Task Edit'),
        ),
        body: SafeArea(child: Column(children: [
          Padding(
            padding: EdgeInsets.all(10),
            child: Form(
              key: formKey,
              //pEditing: EdgeInsets.all(10),
              child: Column(
                children: [
                  TextFormField(
                    controller: tc,
                    onSaved: (value){
                      name = value;
                      print("!!!!! Task Name is $name");
                    },
                    validator: (value){
                      if(value!=null){
                    if(  value.isEmpty){
                      return "Task Name is Required";
                    }
                    else
                    if(value.length<3){
                          return "Task Name is Too Small";
                    }
                    else
                    if(value.length>15){
                      return "Task Name is Too Big";
                    }
                      }
                    return null;
                  },
                    //cursorColor: Colors.red,
                    //cursorRadius: Radius.circular(10),
                    //cursorWidth: 10,
                    autofocus: true,
                    autocorrect: true,
                    //obscureText: true,
                    textAlign: TextAlign.center,
                    decoration:InputDecoration(
                    hintText: 'Type Task Name',
                    labelText: 'Task Name',
                    border: OutlineInputBorder(borderRadius:BorderRadius.circular(10) )
                  )),
                
                 Padding(
            padding: EdgeInsets.all(10),
          child:TextFormField(
            controller: tc2,
            onSaved: (value){
              desc = value;
              print("desc saved $desc ****************");
            },
            validator: (value){
              if(value!=null && value.isEmpty){
                return "Task Desc is Required";
              }
              return null;
            },
            keyboardType: TextInputType.multiline,
            textCapitalization: TextCapitalization.words,
            maxLines: 7,
             decoration:InputDecoration(
             hintText: 'Type Desc ',
              labelText: 'Task Desc',
              border: OutlineInputBorder(borderRadius:BorderRadius.circular(10) ))
          )),

            SizedBox(height: 10,),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Row(
              children: [
                Expanded(
                  child: ElevatedButton(onPressed: () async{
                    FormState ff;
                    dynamic fm = formKey.currentState;
                    print("##### Task Name is $name");
                    //print(fm.fields);
                    
                    print(formKey.currentState);
                     var formCurrentState = formKey.currentState;
                     formCurrentState?.save(); // trigger onSave
                     /*
                     Task task = new Task(name, desc);
                     String json = task.toJson(); // Serializable 
                      dio.post(URL, json);
                     */
                     //formCurrentState.save();
                      if(formCurrentState!=null && formCurrentState.validate()){
                          print("Valid Data");
                          TaskItem taskItem = TaskItem(name.toString(), desc.toString(), DateTime.now().toString());
                          String message = await TaskOperations.addTask(taskItem);
                          print("Message is $message");
                      }
                      else{
                        print("Not Valid Data");
                      }
                  }, child: Text('Edit Task'),
                  style: ButtonStyle(
                    
                    backgroundColor: MaterialStateProperty.all(Colors.deepOrangeAccent)),
                   ),
                ),
              ],
            ),
          )

                ],
              ),
              
            ),
          ),
          
         
          
        ],),),
    );
  }
}
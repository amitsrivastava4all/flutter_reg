import 'package:flutter/material.dart';
import 'package:task_manager_app/domain/models/user.dart';
import 'package:task_manager_app/pages/widgets/header.dart';
import 'package:task_manager_app/pages/widgets/profile.dart';

class Wave extends StatelessWidget {
  //const Wave({ Key? key }) : super(key: key);
  User? user;
  Wave(this.user);
  @override
  Widget build(BuildContext context) {
    Size deviceSize = MediaQuery.of(context).size;
    return ClipPath(
      clipper: WaveClipPath(),
      child: Container(
        height: deviceSize.height/2,
        decoration: const BoxDecoration(
          
          gradient: LinearGradient(colors:  [
          Colors.yellow, Colors.amberAccent, Colors.deepOrangeAccent
        ],begin: Alignment.topLeft, end:Alignment.bottomRight)),
        //color: Colors.amber,
        child: Column(children:  [
          Header(),
          Profile(this.user)
    
        ],),
      ),
    );
  }
}

class WaveClipPath extends CustomClipper<Path>{
  @override
  Path getClip(Size size) {
    var path =  Path();
    path.lineTo(0, size.height-50);
    path.quadraticBezierTo(0.20*size.width, size.height, 0.60* size.width,size.height-100);
    path.lineTo(0.60* size.width, size.height-100);
    path.quadraticBezierTo(0.80*size.width, size.height-150,  size.width,size.height-100);
    path.lineTo(size.width, size.height-50);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) {
    // TODO: implement shouldReclip
    return false;
  }
  
}
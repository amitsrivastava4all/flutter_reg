import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_signin_button/button_view.dart';
import 'package:flutter_signin_button/flutter_signin_button.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:task_manager_app/domain/models/user.dart';
import 'package:task_manager_app/domain/services/user_operations.dart';
import 'package:task_manager_app/pages/tasks.dart';
import 'package:task_manager_app/pages/user_login.dart';
import 'package:task_manager_app/utils/config.dart';
import 'package:video_player/video_player.dart';
import 'package:flutter_facebook_login/flutter_facebook_login.dart';
import 'dart:convert' ;
class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  late VideoPlayerController _videoPlayerController;

  _loginWithGoogle() async {
    UserOperations userOpr = UserOperations();
    User user = await userOpr.login();
    print("##################### User Info is $user");
  }
  FacebookLogin facebookSignIn = new FacebookLogin();
  _loginWithEmailAndPassword(){
    // Open a Screen
  }
  _loginWithFaceBook() async{
     final FacebookLoginResult result =
        await facebookSignIn.logIn(['email']);
        print("######## Result is $result");

switch (result.status) {
      case FacebookLoginStatus.loggedIn:
        final FacebookAccessToken accessToken = result.accessToken;
        // Store the Userid
        // Call the API
        print('''
         Logged in!

         Token: ${accessToken.token}
         User id: ${accessToken.userId}
         Expires: ${accessToken.expires}
         Permissions: ${accessToken.permissions}
         Declined permissions: ${accessToken.declinedPermissions}
         ''');
         // Call Profile
         Future<Response?> future = UserOperations.getUserInfo(accessToken.userId, accessToken.token);
          future.then((response){
              dynamic data = response?.data;
             print("DATA IS ${data.runtimeType}");
              Map<String, dynamic> map = jsonDecode(data);
              print("MAP URL ${map['url']}");
              User user =  User.takeEmailAndPic( map['email'],map['url']);
              Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (ctx)=>TaskList(user)));
              
          }).catchError((err){
            print("Error During FB Profile $err");
          });
        break;
      case FacebookLoginStatus.cancelledByUser:
        print('Login cancelled by the user.');
        break;
      case FacebookLoginStatus  .error:
        print('Something went wrong with the login process.\n'
            'Here\'s the error Facebook gave us: ${result.errorMessage}');
        break;
    }

  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _videoPlayerController = VideoPlayerController.network(Config.VIDEO_URL);
    _videoPlayerController.setLooping(true);
    //_videoPlayerController
      //  .initialize()
       // .then((value) => setState(() {}))
       // .catchError((err) => print("ERROR IS $err"));
    //_videoPlayerController.play();
  }

  _showLoginScreen(){
    Navigator.of(context).push(MaterialPageRoute(builder: (ctx)=>UserLogin()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [
        //VideoPlayer(_videoPlayerController),
        Center(
            child:
                Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(
            'Login',
            style: GoogleFonts.pacifico(color: Colors.white, fontSize: 30),
          ),
          SignInButton(Buttons.Google, onPressed: () {
            _loginWithGoogle();
          }),
          SignInButton(Buttons.Facebook, onPressed: () {
            _loginWithFaceBook();
          }),
          SignInButtonBuilder(
            text: 'Sign in with Email',
            icon: Icons.email,
            onPressed: () {
              _showLoginScreen();
            },
            backgroundColor: Colors.blueGrey[700]!,
          )
        ])),
      ]),
    );
  }
}

class User {
  static int counter = 0;
  int x = 1;
  User() {
    counter++;
    print("User Created... $counter");
  }
  static void show() {
    //x++;
    print("I am Show");
  }

  void output() {
    counter++;
  }
}

void main() {
  User.show();

  // new User();
  // new User();

  // new User();
}

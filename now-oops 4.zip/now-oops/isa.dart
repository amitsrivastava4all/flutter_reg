abstract class Account {
  late int id;
  late String name;
  late double balance;
  @deprecated
  void roi() {
    print("ROI is 4%");
  }

  factory Account.factory(String type) {
    Account account;
    if (type == 'SA') {
      account = new SavingAccount("SA");
    } else {
      account = new CurrentAccount(1001, "A", 7777, 4444);
    }
    return account;
  }

  double getBalance() {
    return balance;
  }

  void transReport() {}
  //void transReport(); // bodyless method (abstract method)

  // Account() {
  //   print("I am Account Default Cons");
  //   id = 0;
  //   name = "A";
  //   balance = 9000;
  // }
  Account(this.id, this.name, this.balance);

  @override
  String toString() => 'Account(id: $id, name: $name, balance: $balance)';
}

class SavingAccount extends Account {
  late String nomName;
  SavingAccount(String nomName) : super(101, "A", 9999) {
    this.nomName = nomName;
    // by default it is calling parent class default cons
    // use special thing e.g super(); it is calling parent cons by using super constructor call
    print("Saving Account Default Cons");
  }
  @override
  void roi() {
    super.roi();
    print("3% ROI");
  }

  void doorToDoor() {
    print("Cash Collected By Bank Ex");
  }

  @override
  String toString() => 'SavingAccount(nomName: $nomName) ${super.toString()}';

  @override
  void transReport() {
    // TODO: implement transReport
    print("SA Trans Report....");
  }
}

class CurrentAccount extends Account {
  late double odLimit;
  @override
  void transReport() {
    // TODO: implement transReport
    print("CA Trans Report....");
  }

  CurrentAccount(int id, String name, double balance, double odLimit)
      : super(id, name, balance) {
    this.odLimit = odLimit;
  }
  void printNoOfTrans() {
    print("UnLimited Trans");
  }

  @override
  void roi() {
    print("Charge 5% ROI");
  }
}

/*void commonCaller(Account account) {
  print(account.getBalance());
  account.roi(); // calling overridden version
  if (account is SavingAccount) {
    SavingAccount sa = account as SavingAccount; // Downcasting
    sa.doorToDoor();
  } else if (account is CurrentAccount) {
    CurrentAccount ca = account as CurrentAccount;
    ca.printNoOfTrans();
  }
}*/

void main() {
  Account ac = new Account.factory('SA');
  ac.roi();
  ac = new Account.factory('CA');
  ac.roi();
  //commonCaller(new Account(10, "A",555));
  // commonCaller(new SavingAccount("X"));
  // commonCaller(new CurrentAccount(101, "A", 9000, 2000));
  // Account account = new SavingAccount("X"); // Upcasting
  // account.getBalance();
  // account.roi();
  // //account.doorToDoor();
  // account = new CurrentAccount(101, "A", 9000, 2000);
  //var savingAccount = SavingAccount("X");
  // savingAccount.roi();
  // print(savingAccount.getBalance());
  // savingAccount.doorToDoor();
  // //print(savingAccount); // savingAccount.toString()
  // var currentAccount = CurrentAccount(101, "A", 9000, 2000);
  // currentAccount.roi();
  // print(currentAccount.getBalance());
  // currentAccount.printNoOfTrans();
}

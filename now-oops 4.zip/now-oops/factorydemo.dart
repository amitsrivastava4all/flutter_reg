final String choice = "p3";

class Consumer1 {
  Producer pr = Producer.factory(choice);
  //Producer2 pr = new Producer2();
}

class Consumer2 {
  Producer pr = Producer.factory(choice);
  // Producer2 pr = new Producer2();
}

class Consumer3 {
  Producer pr = Producer.factory(choice);
  // Producer2 pr = new Producer2();
}

abstract class Producer {
  Producer() {}
  factory Producer.factory(String type) {
    Producer producer;
    if (type == "p2") {
      producer = new Producer2();
    } else {
      producer = new Producer3();
    }
    return producer;
  }
  void output();
}

class Producer2 extends Producer {
  @override
  void output() {
    print("Producer2 call");
    // TODO: implement output
  }
}

class Producer3 extends Producer {
  @override
  void output() {
    print("Producer3 call");
    // TODO: implement output
  }
}

void main() {
  new Consumer1().pr.output();
  new Consumer2().pr.output();

  new Consumer3().pr.output();
}

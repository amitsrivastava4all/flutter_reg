class X {
  @override
  void noSuchMethod(Invocation invocation) {
    print("No Such Method Called ");
  }
}

void main() {
  dynamic obj = new X();
  obj.show();
}

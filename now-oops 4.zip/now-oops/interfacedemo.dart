class Player {
  void kick() {}
  void jump() {}
  void run() {}
  void punch() {}
}

class StarPlayer {
  void hide() {}
}

abstract class HybridPlayer implements Player, StarPlayer {}

class Vega implements HybridPlayer {
  @override
  void jump() {
    print("Vega Jump Very High");

    // TODO: implement jump
  }

  @override
  void kick() {
    print("Vega Kick Average");

    // TODO: implement kick
  }

  @override
  void punch() {
    print("Vega Punch High");

    // TODO: implement punch
  }

  @override
  void run() {
    print("Vega Run Fast");

    // TODO: implement run
  }

  @override
  void hide() {
    // TODO: implement hide
  }
}

class Ryu implements Player {
  @override
  void jump() {
    print("Ryu Jump High");
  }

  @override
  void kick() {
    print("Ryu Best Kick");

    // TODO: implement kick
  }

  @override
  void punch() {
    print("Ryu Average Punch");

    // TODO: implement punch
  }

  @override
  void run() {
    print("Ryu Run Fast");

    // TODO: implement run
  }
}

void main() {
  var ryu = new Ryu();
  ryu.jump();
  ryu.kick();
  ryu.punch();

  var vega = new Vega();
  vega.jump();
  vega.kick();
  vega.punch();
}

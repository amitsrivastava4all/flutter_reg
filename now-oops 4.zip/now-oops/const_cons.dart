class Person {
  final int id;
  final String name;
  final String country;
  const Person(this.id, this.name, this.country);

  @override
  String toString() => 'Person(id: $id, name: $name, country: $country)';
}

void main() {
  StringBuffer sb = new StringBuffer("Hello");
  sb.write("Ok");
  Person amit = const Person(1001, "Amit", "India");
  Person amit2 = const Person(1001, "Amit", "India");
  Person amit3 = const Person(1002, "Amit", "India");
  print(amit == amit2);
  print(amit == amit3);

  print(identical(amit, amit2));
}

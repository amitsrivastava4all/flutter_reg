import 'producer.dart';

class ProducerImpl implements Producer {
  @override
  void dontshow() {
    // TODO: implement dontshow
    print("Producer Impl Dont Show");
  }

  @override
  void show() {
    print("Producer Impl Show");
    // TODO: implement show
  }
}

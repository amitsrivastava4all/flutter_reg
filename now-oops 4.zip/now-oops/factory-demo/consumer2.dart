import 'factory.dart';
import 'producer.dart';

void main() {
  Producer p = Factory.getInstance();
  p.show();
  //p.dontshow();
}

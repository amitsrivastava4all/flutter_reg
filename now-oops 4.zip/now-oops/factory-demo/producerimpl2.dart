import 'producer.dart';

class ProducerImpl2 implements Producer {
  void dontshow() {
    // TODO: implement dontshow
    print("Producer Impl2 Dont Show");
  }

  @override
  void show() {
    print("Producer Impl2 Show");
  }
}

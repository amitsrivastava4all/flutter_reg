import 'producer.dart';
import 'producerimp.dart';
import 'producerimpl2.dart';

class Factory {
  Factory._init() {}
  static Producer getInstance() {
    return new ProducerImpl2();
  }
}

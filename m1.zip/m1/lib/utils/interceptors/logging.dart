import 'package:dio/dio.dart';

class Logging extends Interceptor {
  late int startTime;
  late int endTime;
  @override
  void onRequest(
    RequestOptions options,
    RequestInterceptorHandler handler,
  ) {
    startTime = DateTime.now().millisecond;

    options.headers['AuthToken'] = 1001;
    print('Start Time $startTime  Start ::: Interceptor');
    super.onRequest(options, handler); // move to the request
  }

  @override
  void onResponse(
    Response response,
    ResponseInterceptorHandler handler,
  ) {
    endTime = DateTime.now().millisecond;
    print('End Time $endTime  Here ::: Interceptor $response');
    print("Total Time Taken ${endTime - startTime} ms");
    super.onResponse(response, handler);
  }

  void onError(
    DioError err,
    ErrorInterceptorHandler handler,
  ) {
    print("Error Log $err");
    super.onError(err, handler);
  }
}

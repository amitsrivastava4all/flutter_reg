import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:statedemo/bloc/counter_bloc.dart';

import 'package:statedemo/screens/counter_screen.dart';

void main() async {
  runApp(MaterialApp(
    home: BlocProvider<CounterBloc>(
        create: (ctx) => CounterBloc(), child: CounterScreen()),
  ));
}

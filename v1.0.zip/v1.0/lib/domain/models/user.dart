class User {
  String? email;
  String? name;
  String? photo;
  User(this.email, this.name, this.photo);

  @override
  String toString() {
    return "Email $email Name $name Photo $photo";
  }
}

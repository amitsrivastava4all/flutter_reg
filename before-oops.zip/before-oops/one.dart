void main() {
  // result is a local variable
  int result = add(10, 20);
  print("Result is $result");
}

int z = 1;
int add(int x, int y) {
  return x + y + z;
}

int sub(int x, int y) {
  return x - y - z;
}

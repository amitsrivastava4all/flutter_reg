import './one.dart' as one;
import './three.dart';

void main() {
  //print(add(10, 90));
  one.z = 1111111;
  print(one.add(10, 20));
  add();
}

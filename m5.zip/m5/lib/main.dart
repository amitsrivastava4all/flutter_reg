import 'package:flutter/material.dart';
import 'package:music_app/screens/futurebuilderdemo.dart';
import 'package:music_app/screens/music_player.dart';

import 'screens/streambuilderdemo.dart';

void main() {
  runApp(MaterialApp(title: 'Music App', home: StreamBuilderDemo()
      //home: MusicPlayer()
      ));
}

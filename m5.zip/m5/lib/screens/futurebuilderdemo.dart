import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:music_app/utils/api_client.dart';

class FutureBuilderDemo extends StatefulWidget {
  const FutureBuilderDemo({Key? key}) : super(key: key);

  @override
  _FutureBuilderDemoState createState() => _FutureBuilderDemoState();
}

class _FutureBuilderDemoState extends State<FutureBuilderDemo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
      child: FutureBuilder<Response>(
        future: ApiClient.getSongsByDIO(),
        builder: (BuildContext ctx, AsyncSnapshot<Response> snapShot) {
          if (snapShot.hasError) {
            return Center(
              child: Text('OOPS Some Error Occur'),
            );
          } else if (!snapShot.hasData) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
          return Text(snapShot.data.toString());
        },
      ),
    ));
  }
}

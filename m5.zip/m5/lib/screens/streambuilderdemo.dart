import 'package:flutter/material.dart';
import 'package:music_app/utils/stream.dart';

class StreamBuilderDemo extends StatefulWidget {
  const StreamBuilderDemo({Key? key}) : super(key: key);

  @override
  _StreamBuilderDemoState createState() => _StreamBuilderDemoState();
}

class _StreamBuilderDemoState extends State<StreamBuilderDemo> {
  @override
  Widget build(BuildContext context) {
    AutoIncrementStream autoIncrementStream = new AutoIncrementStream();
    Stream<int> stream = autoIncrementStream.getStream();
    return Scaffold(
      body: SafeArea(
        child: StreamBuilder<int>(
          stream: stream,
          builder: (BuildContext ctx, AsyncSnapshot<int> snapshot) {
            if (snapshot.hasError) {
              return Center(child: Text('Some Error Occur in Stream'));
            } else if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(
                child: CircularProgressIndicator(),
              );
            }
            return Center(
              child: Text(
                snapshot.data.toString(),
                style: TextStyle(fontSize: 30),
              ),
            );
          },
        ),
      ),
    );
  }
}

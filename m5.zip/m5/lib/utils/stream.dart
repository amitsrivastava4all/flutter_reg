import 'dart:async';

class AutoIncrementStream {
  int _counter = 0;
  StreamController<int> _streamController = new StreamController<int>();
  AutoIncrementStream() {
    Timer.periodic(Duration(seconds: 3), (timer) {
      _counter++;
      _streamController.sink.add(_counter);
    });
  }
  Stream<int> getStream() {
    return _streamController.stream;
  }
}

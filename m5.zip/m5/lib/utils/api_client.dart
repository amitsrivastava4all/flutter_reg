import 'package:dio/dio.dart';
import 'package:http/http.dart' as http;
import 'package:music_app/utils/interceptors/logging.dart';

// Server Call
class ApiClient {
  // class DioClient
  ApiClient._() {}
  static final String BASE_URL = "https://itunes.apple.com";
  static Future<Response> getSongsByDIO({String artistName = "Sonu Nigam"}) {
    BaseOptions options = new BaseOptions(
      baseUrl: BASE_URL,
      connectTimeout: 7000,
      receiveTimeout: 6000,
      method: 'get',
    );
    Dio dio = new Dio(options);
    dio.interceptors.add(new Logging());
    String RELATIVE_PATH = "/search?term=${artistName}&limit=50";
    Future<Response> future = dio.get(RELATIVE_PATH);
    return future;
  }

  static Future<Response> postSong({String artistName = "Sonu Nigam"}) {
    Dio dio = new Dio();
    Map<String, dynamic> map = {"id": 1001, "name": 'Amit', "city": 'Delhi'};
    String RELATIVE_PATH = "/search?term=${artistName}&limit=25";
    Future<Response> future = dio.post(BASE_URL + RELATIVE_PATH, data: map);
    return future;
  }

  static Future<http.Response> getSongs(String artistName) {
    String RELATIVE_PATH = "/search?term=${artistName}&limit=25";
    String fullURL = BASE_URL + RELATIVE_PATH;
    Future<http.Response> future = http.get(Uri.parse(fullURL));
    return future;
    /*future.then((response) {
      String responseBody = response.body;
      print("Body Type ${responseBody.runtimeType}");
      print("Response Body $responseBody ");
    }).catchError((err) => print("Error Rec During Server Call ${err}"));*/
  }
}

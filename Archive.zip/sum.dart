void main() {
  List<int> list = [10, 90, 100, 20, 88, 33];
  // Imperative
  // int sum = 0;
  // for (int i = 0; i < list.length; i++) {
  //   sum += list[i];
  // }
  // print("Sum is $sum");
  // Declerartive Way
  int sum = list.fold(0, (previousValue, element) => previousValue + element);
  print("Sum is $sum");
}

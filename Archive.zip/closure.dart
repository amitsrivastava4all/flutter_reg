Function init() {
  int count = 0; // Local Scope
  int countDown() {
    count++; // count = count + 1; // Lexical Scope
    return count;
  }

  return countDown; // return Fn + Lexical Scope = Closure
}

void main() {
  Function fn = init();
  print(fn());
  print(fn());
  print(fn());
  print(fn());
}

Map<String, Function> Math() {
  int n = 1;
  final Function sin = () => 10 + n;
  final Function cos = () => 20 + n;
  return {"sin": sin, "cos": cos};
}

void main() {
  Map<String, Function> map = Math();
  print(map["sin"]!());
  print(map["cos"]!());
}

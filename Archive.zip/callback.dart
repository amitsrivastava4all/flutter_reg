// 1 to N Even Odd
// 1 to N Cube
// 1 to N Square
final evenOdd = (num) => num % 2 == 0 ? "Even No $num" : "Odd No $num";
final cube = (num) => num * num * num;
final square = (num) => num * num;
void loop(int n, Function fn) {
  for (int i = 1; i <= n; i++) {
    print(fn(i));
  }
  print("****************************");
}

// Dart is a single Threaded.
// Thread == Worker
void main() {
  loop(10, evenOdd);
  loop(10, cube);
  loop(10, square);
}

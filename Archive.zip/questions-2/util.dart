final properCase =
    (String str) => str[0].toUpperCase() + str.substring(1).toLowerCase();
String getFullName(String name) {
  List<String> names = name.split(" ");
  String fullName = "";
  for (String n in names) {
    fullName += properCase(n) + " ";
  }
  return fullName.trim();
}

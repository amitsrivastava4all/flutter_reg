import './util.dart';

class Student {
  int _id;
  String _name;
  List<int> _subjects;
  String _instName;
  late int _age;
  int total() {
    return _subjects.fold(0, (sum, subject) => sum + subject);
    // int sum = 0;
    // for (int subject in subjects) {
    //   sum += subject;
    // }
    // return sum;
  }

  int per() {
    return total() ~/ _subjects.length;
  }

  String grade() {
    int percentage = per();
    if (percentage >= 90) {
      return "A Grade";
    } else if (percentage < 90 && percentage >= 70) {
      return "B Grade";
    } else if (percentage < 70 && percentage >= 50) {
      return "C Grade";
    } else {
      return "D Grade";
    }
  }

  Student(
      {required int id,
      required String name,
      required List<int> subjects,
      required String instName})
      : this._id = id,
        this._name = name,
        this._subjects = subjects,
        this._instName = instName;
  int get id => this._id;

  set id(int value) => this._id = value;

  get name => this._name;

  set name(value) => this._name = value;

  get subjects => this._subjects;

  set subjects(value) => this._subjects = value;

  get instName => this._instName;

  set instName(value) => this._instName = value;

  get age => this._age;

  set age(value) => this._age = value;
  @override
  String toString() {
    return """ Id $id
             Name ${getFullName(name)}
             Subjects $subjects
             College Name $instName
             Total    ${total()}
             Per      ${per()}
             Grade    ${grade()}
             """;
  }
}

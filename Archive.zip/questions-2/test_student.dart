import 'dart:io';
import './student.dart';

void main() {
  print("Enter the Id");
  int id = int.parse(stdin.readLineSync().toString());
  print("Enter the Name");
  String name = stdin.readLineSync().toString();
  print("Enter the Marks of 3 Subjects");
  List<int> marks = [];
  for (int i = 1; i <= 3; i++) {
    marks.add(int.parse(stdin.readLineSync().toString()));
  }
  print("Enter the College Name");
  String collegeName = stdin.readLineSync().toString().toUpperCase();
  Student student =
      new Student(id: id, name: name, subjects: marks, instName: collegeName);
  print(student);
}

void main() {
  List<int> list = [10, 20];
  list.add(90);
  list.insert(1, 5454);
  list[0] = 33;
  list.addAll([90, 1000, 2000]);
  print(list);
  int index = list.indexOf(10000);
  // list.remove(90);
  // list.removeAt(0);
  // list.removeLast();
  // //list.clear();
  print(list.elementAt(0));
  print(list.contains(1000)); // true or false
  print("Index is $index");
  print("########################");
  //list.forEach((int element) => print("Element $element"));
  list
      .where((element) => element > 90)
      .forEach((element) => print("Element $element"));
  bool result = list.every((element) => element > 90);
  result = list.any((element) => element > 90);
  //print("Every Element $result");
  print("Any Element $result");
  index = list.firstWhere((element) => element > 90);
  list = [10, 2, 90, 1, 100, 3];
  //list.sort((int first, int second) => first - second);
  //list.sort((int first, int second) => second - first);
  list.sort((int first, int second) => second.compareTo(first));
  List<String> names = ["ram", "amit", "shyam", "anil"];
  print("Sorted $list");
  // names.sort((String first, String second) => first.compareTo(second));
  names.sort((String first, String second) => second.compareTo(first));
  print("NAmes are $names");
}

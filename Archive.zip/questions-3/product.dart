class Product {
  int _id;
  String _name;
  double _price;
  Product({
    required int id,
    required String name,
    required double price,
  })  : this._id = id,
        this._name = name,
        this._price = price;

  @override
  String toString() => 'Product(_id: $_id, _name: $_name, _price: $_price)';
}

import 'product.dart';

class Order {
  int _id;
  String _name;
  List<Product> _products = [];
  int get id => this._id;

  set id(int value) => this._id = value;

  get name => this._name;

  set name(value) => this._name = value;

  get products => this._products;

  set products(value) => this._products = value;
  Order(
      {required int id, required String name, required List<Product> products})
      : this._id = id,
        this._name = name,
        this._products = products;

  @override
  String toString() =>
      'Order(_id: $_id, _name: $_name , Products : $_products)';
}

class Address {
  String _city;
  String _country;
  Address(this._city, this._country);
  String get country => this._country;

  set country(String value) => this._country = value;

  get city => this._city;

  set city(value) => this._city = value;

  String toString() {
    return "City $city Country $country";
  }
}

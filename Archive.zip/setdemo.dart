void main() {
  Set<int> set = {1, 2, 2, 3, 1, 2, 1, 100, 900}; // Close to Java
  var set2 = {1, 2, 4, 2, 1}; // Close to JavaScript
  print(set);
  Set s4 = Set.from({10, 20, 30}); //Named Constructor
  Set<int> set3 = new Set(); // Constructor
  Set<int> set4 = Set();
  set.add(545);
  for (int x in set) {
    print(x);
  }
  // Properties
  print(set.first);
  print(set.last);
  print(set.length);
  print(set.isEmpty);
  // Methods
  set.add(1000);
  // set.clear();
  set.contains(100); // bool true, false
  set.elementAt(0);
  Set s5 = {10, 20, 30}.difference({10, 20, 90});
  print(s5);
  s5 = {10, 20, 30}.intersection({10, 20, 90});
  print(s5);
  List<int> s6 = set.toList();
  print("###########################");
  Set<int> s7 = {90, 100, 200, 1, 2, 3};
  print("Value is $set");
  var x = s7.takeWhile((value) => value > 5);
  x.forEach((element) => print(element));
}

void main() {
  String name = "amit";
  String name3 = "amit";
  String name2 = name.toUpperCase();
  print(name == name2);
  print(name == name3);
}

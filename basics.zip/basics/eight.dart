/// Example of const and final in Dart
/// @return void

void main() {
  /// int a is a basic datatype
  int a = 100;
  const int MAX = 100;
  final StringBuffer sb2 = StringBuffer();
  //sb2 = new StringBuffer();
  sb2.write("Hi");
  sb2.write("Hello");
  // Single line comment
  /*
  Multi line comment
  */
  // if (a > 1) {
  //   MAX = 100;
  // } else {
  //   MAX = 200;
  // }
  print("MAX is ${MAX}");
  //MAX = 999;
  /*String sql = "select * from products";
  double price = 9000;
  sql = sql + "where price = ${price}";
  String brand = "nike";
  sql = sql + " and brand  = ${brand}";*/
  StringBuffer sb = new StringBuffer();
  sb.write("select * from products");
  double price = 9000;
  sb.write(" where price =${price}");
  print(sb.toString());
}

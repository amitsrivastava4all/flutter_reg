void main() {
  String? name; // can be null
  int age;
  print(name);
  //age++;
}

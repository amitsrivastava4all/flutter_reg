import 'dart:io';

void main() {
  String? name;
  int? age;
  print("Enter the Name");
  name = stdin.readLineSync();
  print("Enter the Age");
  age = int.parse(stdin.readLineSync().toString());
  print("Name is $name and Age is $age");
  // String? temp = stdin.readLineSync();
  // age = int.parse(temp.toString());
}

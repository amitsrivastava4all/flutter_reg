void main() {
  String firstName = "Amit";
  // Properties
  print(firstName.length);
  print(firstName.isEmpty);
  print(firstName.isNotEmpty);
  print(firstName.codeUnits);
  print(firstName.runtimeType);
  print(firstName is String);
  // Methods
  print(firstName.toUpperCase());
  print("      Amit   Srivastava    ".trim());
  print("Contains ${firstName.contains("mi")}");
  print(firstName.startsWith("Am"));
  print(firstName.endsWith("it"));
  String address = "A-1, Shakti Nagar, Delhi-7";
  List<String> list = address.split(",");
  print(list);
  print("IndexOf ${firstName.indexOf("e")}");
  print(firstName.codeUnitAt(0)); // Ascii of First Char
  String lastName = "Srivastava";
  print(firstName + lastName);
  String t = 'Hello' 'How' 'Are You';
  print(t);
  print(t[0]);
}

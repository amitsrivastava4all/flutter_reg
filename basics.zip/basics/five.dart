void main() {
  // Basic Data Types
  int a = 100; // Statisically Typed
  var b = 100; // Type Inference
  print(a.runtimeType);
  print(b.runtimeType);
  int c = int.parse("100", radix: 10);
  String d = a.toString();
  double price = 90.70;
  String d1 = price.toString();
  price = 90.54534432423;
  print(price);
  print(price.toStringAsFixed(2));
  bool att = true;
  String name = "Amit";
  String name2 = 'Amit';
  String msg = 'gdjghfdjkgdfkhg'
      'ghdfjkhgjkdfhgkhjdf'
      'ghdfjkhgfkjdhgfkdjhgkjdfhrtweyurtewyur';
  print(msg);
  String multi = """jghfdhjgjdfhgjkhdfjkg
  gfdhjkfgdjkfg
  ghfdjkghjkdf
  teruityreyt
  nvmbnmcvc""";
  print(multi);
}

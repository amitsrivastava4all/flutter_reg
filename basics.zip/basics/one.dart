//import 'dart:core';

import 'dart:io';

void main() {
  //print("Hi Dart");
  //stdout.write("hi Dart");
  int a = 100;
  int b = 200;
  stdout.writeln("Hi Dart ${a + b}");
  print("Hello Dart $a and $b");
  print("A is " + a.toString());
}

void main() {
  String b = "100";
  int a = int.parse(b);
  String c = a.toString();
  print(int.parse("765", radix: 10));
}

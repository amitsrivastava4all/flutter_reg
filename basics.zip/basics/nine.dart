import 'dart:convert' as myobj;

void main() {
  String? name;
  if (10 > 2) {
    name = "Amit";
  }
  name ??= "Name is Missing in DB";
  print(name);
  print(name is String);
  var phones = [9999, 2333, 4555];
  print(phones is! List);
  print(2 + 3);
  print(5 / 2);
  print(5 ~/ 2);
  String myName = "Amit";
  myName.toUpperCase().substring(1).toLowerCase();
  StringBuffer sb = new StringBuffer();
  sb..write("HI")..write("Hello")..write("Ok");
  print(sb);
  //print("Your Name is ${name ?? 'Missing Contact to Admin'}");
}

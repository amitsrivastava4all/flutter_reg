// CRUD
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:task_manager_app/domain/models/task_items.dart';

class TaskOperations{
  static final FirebaseFirestore firestore = FirebaseFirestore.instance;
  TaskOperations._(){}

  static Stream<QuerySnapshot> readAllTask(){
      final CollectionReference taskCollection = firestore.collection('tasks');
      //Future<QuerySnapshot> future = taskCollection.get()
      return taskCollection.snapshots();
  }

  static Future<String> addTask(TaskItem taskItem) async{
    final CollectionReference _taskCollection = firestore.collection('tasks');
    DocumentReference documentReference =_taskCollection.doc();
    try{
    await  documentReference.set(taskItem.toJSON());
    return "Task Added";
    }
    catch(err){
      print(err);
      return "Error in Task Added";
    }
  }
}
import 'package:dio/dio.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:task_manager_app/domain/services/oauth.dart';
import '../models/user.dart' as userModel;

class UserOperations {

  static Future<Response?> getUserInfo(userid, accessToken) async{
    String URL = "https://graph.facebook.com/v12.0/$userid?access_token=$accessToken&fields=picture,email";
    try{
    Response response = await Dio().get(URL);
    //response.data
   // User user = new User();
    //user.email = response['data']['email'];
    //return user;
    print("Response is $response");
    return response;
    }
    catch(err){
      print("Erorr in Profile Call $err");
    }
  }

  Future<userModel.User> login() async {
    OAuth oAuth = new OAuth();
    UserCredential userCred = await oAuth.login(); // Login with Gmail
    User? user = userCred.user; // FireBase User
    String? name = user?.displayName;
    String? email = user?.email;
    String? photo = user?.photoURL;
    userModel.User userObject =
        userModel.User(email, name, photo); // Our Model User
    return userObject;
  }


  static Future<String> createUserWithEmailAndPassword(userModel.User user)async{
    final FirebaseAuth _auth = FirebaseAuth.instance;
      String emailId = user.email.toString();
      String password = user.password.toString();
      try{
       await _auth.createUserWithEmailAndPassword(email: emailId, password: password);
        return "User Register SuccessFully";
      }
      on Exception catch(err){
        print("Exception During Register $err");
        return "Registeration Fails";
      }
  }

  static Future<String?> loginWithEmailAndPassword(userModel.User user) async{
      final FirebaseAuth _auth = FirebaseAuth.instance;
      String emailId = user.email.toString();
      String password = user.password.toString();
      try{
      await _auth.signInWithEmailAndPassword(email: emailId, password: password);
      //return "Login SuccessFully.....";
      return null;
      }
      on Exception catch(err){
        print("Ex During Login with Email and password $err");
        return "Login Fails";
        
      }
  }
}

class TaskItem{
  String title; // title;
  String desc;
  String time;
  
  TaskItem(this.title, this.desc, this.time);

  Map<String, dynamic> toJSON(){
    return {
      "title":title,
      "desc":desc,
      "time":DateTime.now()
    }; 
  }
}
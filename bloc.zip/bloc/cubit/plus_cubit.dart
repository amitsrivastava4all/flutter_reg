import 'package:bloc/bloc.dart';

class PlusCubit extends Cubit<int>{
  PlusCubit(): super(0); // Inital Value set 0
  void plus() => emit(state + 1);
  void minus () => emit(state - 1);
}

void main(){
 PlusCubit obj =  PlusCubit();
 
 print(obj.state); // UI
 
 obj.plus(); // Fn Call
 print(obj.state); // Response state
  obj.plus();
  print(obj.state);
  obj.minus();
  print(obj.state);
}

import 'package:flutter/material.dart';

class TaskList extends StatefulWidget {
  const TaskList({ Key? key }) : super(key: key);

  @override
  _TaskListState createState() => _TaskListState();
}

class _TaskListState extends State<TaskList> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child:Center(child: Text('DashBoard',style: TextStyle(fontSize: 30),),)
    );
  }
}
import 'package:flutter/material.dart';
import 'package:flutter_login/flutter_login.dart';
import 'package:task_manager_app/domain/models/user.dart';
import 'package:task_manager_app/domain/services/user_operations.dart';
import 'package:task_manager_app/pages/tasks.dart';
class UserLogin extends StatelessWidget{
  Future<String?> _authUser(LoginData data){
    print("Login Data is $data");
    //return Future.delayed(Duration(seconds: 1)).then((value) => "User Login");
    User user = User.takeInput(data.name, data.password);
    return UserOperations.loginWithEmailAndPassword(user);
  }
  Future<String?> _recoverPwd(String username){
     return Future.delayed(Duration(seconds: 2)).then((value) => "Pwd Recover");
  }

  Future<String> _reg(SignupData data){
     User user = User.takeInput(data.name, data.password);
      return UserOperations.createUserWithEmailAndPassword(user);
      //return Future.delayed(Duration(seconds: 1)).then((value) => "Reg Done");
  }
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return FlutterLogin(
      onSignup: _reg,
      logo: NetworkImage('https://www.designbust.com/download/1039/png/google_logo_transparent512.png'),
      title:'Brain Mentors',
      onLogin: _authUser,
      onRecoverPassword:_recoverPwd,
      onSubmitAnimationCompleted: (){
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (ctx)=>TaskList()));
      },

    );
  }
}
class User {
  String? email;
  String? name;
  String? photo;
  String? password;
  User(this.email, this.name, this.photo);
  User.takeInput(this.email, this.password);

  
  @override
  String toString() {
    return "Email $email Name $name Photo $photo";
  }
}

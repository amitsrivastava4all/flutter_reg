// Image + Text
class Product {
  late String imageURL;
  late String label;
  Product(this.imageURL, this.label);
}

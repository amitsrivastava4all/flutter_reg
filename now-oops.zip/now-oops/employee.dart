//BluePrint
class Employee {
  // public instance variables
  // _ private (With in File)
  int?
      _id; // When they come in a memory , when object is get created or instance is created
  // that's why these are called instance variables
  String? _name;
  double? _salary;
  String? _companyName;
  // every class by default has default constructor
  // it does nothing
  // Employee() {
  //   print("I am a Default Constructor of an Employee");
  //   _id = 1001;
  //   _name = "Amit";
  //   _salary = 9999;
  //   _companyName = "Brain Mentors";
  // }
  Employee(
      {required int id,
      required String name,
      required double salary,
      String companyName = "Brain Mentors"}) {
    this._id = id;
    this._name = name;
    this._salary = salary;
    _companyName = companyName;
  }
  // Named Constructor
  Employee.takeInput(int id, String name) {
    this._id = id;
    this._name = name;
  }
  /*void takeInput(int id, String name, double salary, String companyName) {
    if (id < 0 || salary < 0) {
      print("Invalid Id or Salary ");
      return;
    }
    this._id = id;
    this._name = name;
    this._salary = salary;
    this._companyName = companyName;
  }*/

  void printDetails() {
    print("Id ${this._id}");
    print("Name $_name");
    print("Salary $_salary");
    print("Name $_companyName");
    print("*************************************");
  }
}

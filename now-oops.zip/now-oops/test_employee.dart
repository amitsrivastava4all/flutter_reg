import './employee.dart';

void main() {
  int age;
  age = 21;
  //Employee amit = Employee(id: 1001, name: "Amit", salary: 5435);
  Employee amit = Employee.takeInput(1001, "Amit");
  // Employee amit;
  // amit = new Employee(
  //     name: "Amit", id: 1001, salary: 9999); // we call default constructor
  // print(amit.id); // 88.id
  // print(amit.name);
  // print(amit.salary);
  // print(amit.companyName);
  // amit._id = -1001;
  // amit._name = "Amit";
  // amit.salary = -99999;
  // amit.companyName = "Brain Mentors";
  //amit.takeInput(-1001, "Amit", -6565, "Brain Mentors");
  amit.printDetails();
  // print(amit.id); // 88.id
  // print(amit.name);
  // print(amit.salary);
  // print(amit.companyName);
  Employee rahul =
      new Employee(salary: 8787, id: 1002, name: "Rahul", companyName: "TCS");
  // rahul.id = 1002;
  // rahul.name = "Rahul";
  // rahul.salary = 99999;
  // rahul.companyName = "Brain Mentors";
  //rahul.takeInput(1002, "Rahul", 6565, "Brain Mentors");
  rahul.printDetails();
  // print(rahul.id); // 88.id
  // print(rahul.name);
  // print(rahul.salary);
  // print(rahul.companyName);
}

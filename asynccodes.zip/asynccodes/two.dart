Future<String> orderAPizza() {
  Future<String> future =
      Future.delayed(Duration(seconds: 7), () => "Pan Pizza Prepared");
  // Future.delayed(Duration(seconds: 7),
  //     () => throw Exception("Sorry Can't Deliever Pizza at Your Area"));
  return future;
}

Future<String> orderADessert() {
  Future<String> future =
      Future.delayed(Duration(seconds: 3), () => "Ice Cream");
  // Future.delayed(Duration(seconds: 7),
  //     () => throw Exception("Sorry Can't Deliever Pizza at Your Area"));
  return future;
}

void main() async {
  print("Pizza Order Example");
  try {
    String result = await orderAPizza();
    print(result);
    String result2 = await orderADessert();
    print(result2);
  } catch (err) {
    print(err);
  }
  // Future<String> future = orderAPizza();
  //  Future<String> future2 = orderADessert();
  //print(future);
  // future.then((value) {
  //   print("Get the Pizza $value");
  //   Future<String> future2 = orderADessert();
  //   future2
  //       .then((value) => print("Get the Pizza $value"))
  //       .catchError((err) => print("Error on Pizza $err"));
  // }).catchError((err) => print("Error on Pizza $err"));

  // future2
  //     .then((value) => print("Get the Pizza $value"))
  //     .catchError((err) => print("Error on Pizza $err"));
}

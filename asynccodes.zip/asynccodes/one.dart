import 'dart:io';

String sayHello() {
  return "Hello Dart";
}

void main() {
  String message = sayHello(); // Sync call
  // Calling + Waiting + Get the Result
  // const path = '/Users/amitsrivastava/Documents/learn-dart/asynccodes/notes.txt';
  final path = Directory.current.path + "/notes.txt";
  print(path);
  File file = new File(path);
  print("Before Calling File Read");
  Future<String> future = file.readAsString();
  print("Future is $future");
  future
      .then((value) => print("Value Rec $value"))
      .catchError((err) => print("Error is $err"));
  print("Main Ends");
}

import 'singleton.dart';

void main() {
  Person? person = Person.getInstance();
  person?.age = 21;
  person?.name = "Amit";
  print("${person?.name} ${person?.age}");
  Person? person2 = Person.getInstance();
  print("${person2?.name} ${person2?.age}");
}

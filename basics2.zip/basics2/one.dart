void main(List<String> args) {
  print("Arguments are $args");
  // print(add(10, 20));
  // print(add());
  // print(add(10));
  print(add(1000, x: 10));
  print(add(555, y: 20));
  print(add(666));
  print(add(555, y: 20, x: 10));
  print(adder(m: 550, y: 33));
  print(adder2());
  List<int> list = [10, 20, 30, 40, 50];
  print(adder2(numbers: list));
  print(adder2(numbers: [32, 54, 656, 434, 212]));
}

int adder2({List<int> numbers = const []}) {
  int sum = 0;
  for (int number in numbers) {
    sum += number;
  }
  return sum;
}

int adder({int x = 0, required int y, int z = 0, required int m, int n = 0}) {
  return x + y + z + m + n;
}

// Optional Named param
int add(int z, {int x = 0, int y = 0, int m = 0}) {
  return x + y;
}
// Optional Positional Param  + Default Param
// int add([int x = 0, int y = 0]) {
//   return x + y;
// }

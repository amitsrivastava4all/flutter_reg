import './functions.dart';
//import './functions2.dart' as fn;
import './functions2.dart';

void main() {
  //print(add(10, 20));
  //List<Function> list = calc();
  Map<String, Function> map = calc();
  Function? fn = map["adder"];
  print(fn!(10, 20)); //Bang
  // if(fn!=null){
  //   print(fn(10, 20));
  // }

  // print(list[0](10, 20));
  // print(list[1](1, 2));
  //print(fn.add(100, 2));
  print(add(10, 20));
}

// int add(int x, int y) {
//   print("Functions....");
//   return x + y;
// }

//List<Function> calc() {
Map<String, Function> calc() {
  Function sub = (x, y) => x - y;
  Function add = (x, y) => x + y;
  // return [add, sub];
  return {"adder": add, "subtract": sub};
  // int sub(int x, int y) {
  //   return x + y;
  // }
}

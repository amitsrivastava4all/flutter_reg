// Command Line Args
void main(List<String> args) {
  int sum = 0;
  for (String arg in args) {
    sum += int.parse(arg);
  }
  print("Sum $sum");
}

import 'package:firstapp/screens/containereg.dart';
import 'package:firstapp/screens/home.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'First App',
    //theme: ThemeData.light(),
    theme: ThemeData(
        scaffoldBackgroundColor: Colors.greenAccent,
        appBarTheme: AppBarTheme(backgroundColor: Colors.black)),
    //home: SafeArea(child: Text('Hello flutter')),
    // home: Home()
    home: ContainerExample(),
  ));
}

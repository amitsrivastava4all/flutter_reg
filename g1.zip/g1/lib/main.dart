import 'package:flutter/material.dart';
import 'package:music_app/screens/music_player.dart';

void main() {
  runApp(MaterialApp(title: 'Music App', home: MusicPlayer()));
}

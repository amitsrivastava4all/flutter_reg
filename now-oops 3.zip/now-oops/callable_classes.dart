// If a class is call like a function is become callable class
class Myclass extends Object {
  @override
  String call(double b, String msg1, String msg2, int x) {
    return "Message is ${msg1} and Message2 is ${msg2}";
  }
}

void main() {
  Myclass obj = new Myclass();
  String result = obj(20.90, "Brain", "Mentors", 10);
  print("Result is $result");
}

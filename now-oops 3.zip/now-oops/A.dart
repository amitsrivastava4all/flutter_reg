class A {
  late int _x;
  late int _y;
  // A({this.x = 0, this.y = 0});
  // A(int x, int y) {
  //   this._x = x;
  //   this._y = y;
  // }
  A({int x = 0, int y = 0})
      : this._x = x,
        this._y = y;
  void display() {
    print("X is $_x and Y is $_y");
  }
}

void main() {
  A a = A(x: 10, y: 20);
  a.display();
}

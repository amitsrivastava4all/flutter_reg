void main() {
  StringBuffer sb = new StringBuffer();
  sb.write("Hello Dart");
  print(sb.toString()); // Hello Dart
  Student ram = new Student(1001, "Ram", "Dart");
  print(ram.toString());
  print(ram);
}

class Student {
  //extends Object {
  late int id;
  late String name;
  late String course;
  Student(this.id, this.name, this.course);
  @override
  String toString() {
    return "Id $id Name $name Course $course";
  }
}

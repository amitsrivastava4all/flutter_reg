import 'package:json_annotation/json_annotation.dart';
part 'song.g.dart';

@JsonSerializable()
class Song {
  @JsonKey(name: "trackName")
  String title;
  @JsonKey(name: "artistName")
  String artist;
  @JsonKey(name: "artworkUrl100")
  String image;
  @JsonKey(name: "previewUrl")
  String audio;
  Song(
      {required this.title,
      required this.artist,
      required this.image,
      required this.audio});

  static Song fromJSON(map) {
    return _$SongFromJson(map);
  }

  toJSON() {
    return _$SongToJson(this);
  }
  // static Song fromJSON(map) {
  //   return Song(
  //       title: map['trackName'],
  //       artist: map['artistName'],
  //       image: map['artworkUrl100'],
  //       audio: map['previewUrl']);
  // }

  // toJSON() {
  //   return {
  //     "trackName": title,
  //     "artistName": artist,
  //     "artworkUrl100": image,
  //     "previewUrl": audio
  //   };
  // }
}

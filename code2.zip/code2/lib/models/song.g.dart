// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'song.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Song _$SongFromJson(Map<String, dynamic> json) {
  return Song(
    title: json['trackName'] as String,
    artist: json['artistName'] as String,
    image: json['artworkUrl100'] as String,
    audio: json['previewUrl'] as String,
  );
}

Map<String, dynamic> _$SongToJson(Song instance) => <String, dynamic>{
      'trackName': instance.title,
      'artistName': instance.artist,
      'artworkUrl100': instance.image,
      'previewUrl': instance.audio,
    };

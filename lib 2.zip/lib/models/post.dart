class Post {
  String url;
  String title;
  String subtitle;
  String time;
  Post(this.url, this.title, this.subtitle, this.time);
}

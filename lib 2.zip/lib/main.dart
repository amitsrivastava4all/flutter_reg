import 'package:flutter/material.dart';
import 'package:ted_app/screens/ted.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Ted(),
  ));
}

class Math {
  // It is like a Noun (Feature)
  int add(int x, int y) {
    return x + y;
  }
}

class Order {
  void add() {
    // it is a verb
  }
}

class Customer {
  void add() {}
}

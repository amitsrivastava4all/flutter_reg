class Employee {
  // Member Variables
  int? id;
  String? name;
  double? salary;
  void takeInput(int id, String name, double salary) {
    this.id = id;
    this.name = name;
    this.salary = salary;
  }

  void empPrint() {
    print("Id $id Name $name Salary $salary");
  }
}

void main() {
  Employee employee = new Employee();
  employee.takeInput(101, 'Abcd', 90000);
  //Employee employee = Employee();
  //var employee = Employee();

  //print(employee.toString());
  employee.empPrint();
}

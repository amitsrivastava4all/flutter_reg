
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:task_manager_app/domain/models/task_items.dart';

class Tasks extends StatelessWidget {
  
  Tasks({ Key? key }) : super(key: key);
  _getItems(){

    this.items =  [
      TaskItem('A', 'AAAA', '11:10AM'),
      TaskItem('B', 'AAAA', '11:10AM'),
      TaskItem('C', 'AAAA', '11:10AM'),
      TaskItem('D', 'AAAA', '11:10AM'),
      TaskItem('E', 'AAAA', '11:10AM'),
      TaskItem('F', 'AAAA', '11:10AM')
    ];
    return items;
  }
  _showTasks(){
    return ListView.builder(
      scrollDirection: Axis.horizontal,
      itemBuilder: (BuildContext ctx, int index){
      return Stack(children: [
        Container(
          margin: EdgeInsets.all(10),
          child: Column(children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
              Icon(Icons.assignment_turned_in_outlined),
              Text(items[index].title)
            ],),
            SizedBox(height: 10,),
            Text(items[index].desc, style: GoogleFonts.roboto(fontSize:20,))
          ],),
          decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(color: Colors.white, spreadRadius: 2)
          ],  
          color: Colors.amberAccent,
          borderRadius: BorderRadius.only(topLeft: Radius.circular(50), bottomRight: Radius.circular(50))
          
        ),
        height: 250,
        width:250
        ),
        Positioned(child: _editButton(), right: 0, top:0)
      ],);
    },itemCount: _getItems().length,);
  }
  List<TaskItem> items = [];
  
  _editButton(){
    return Container(
      decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.redAccent),
      child: IconButton(onPressed: (){},icon:Icon(Icons.mode_edit_sharp)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
     // color: Colors.blue,
      height: 250,
      child: _showTasks()
    );
  }
}
import 'package:flutter/material.dart';

class AddTask extends StatefulWidget {
  const AddTask({ Key? key }) : super(key: key);

  @override
  _AddTaskState createState() => _AddTaskState();
}

class _AddTaskState extends State<AddTask> {
  GlobalKey<FormState> formKey = GlobalKey<FormState>();
  String? name;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Task Add'),
        ),
        body: SafeArea(child: Column(children: [
          Padding(
            padding: EdgeInsets.all(10),
            child: Form(
              key: formKey,
              //padding: EdgeInsets.all(10),
              child: TextFormField(
                onSaved: (value){
                  name = value;
                  print("!!!!! Task Name is $name");
                },
                validator: (value){
                  if(value!=null){
                if(  value.isEmpty){
                  return "Task Name is Required";
                }
                else
                if(value.length<3){
                      return "Task Name is Too Small";
                }
                else
                if(value.length>15){
                  return "Task Name is Too Big";
                }
                  }
                return null;
              },
                //cursorColor: Colors.red,
                //cursorRadius: Radius.circular(10),
                //cursorWidth: 10,
                autofocus: true,
                autocorrect: true,
                //obscureText: true,
                textAlign: TextAlign.center,
                decoration:InputDecoration(
                hintText: 'Type Task Name',
                labelText: 'Task Name',
                border: OutlineInputBorder(borderRadius:BorderRadius.circular(10) )
              )),
            ),
          ),
          SizedBox(height: 10,),
          Padding(
            padding: EdgeInsets.all(10),
          child:TextFormField(
            onSaved: (value){

            },
            validator: (value){
              if(value!=null && value.isEmpty){
                return "Task Desc is Required";
              }
              return null;
            },
            keyboardType: TextInputType.multiline,
            textCapitalization: TextCapitalization.words,
            maxLines: 7,
             decoration:InputDecoration(
             hintText: 'Type Desc ',
              labelText: 'Task Desc',
              border: OutlineInputBorder(borderRadius:BorderRadius.circular(10) ))
          )),
          SizedBox(height: 10,),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Row(
              children: [
                Expanded(
                  child: ElevatedButton(onPressed: (){
                    FormState ff;
                    dynamic fm = formKey.currentState;
                    print("##### Task Name is $name");
                    //print(fm.fields);
                    
                    print(formKey.currentState);
                     var formCurrentState = formKey.currentState;
                     //formCurrentState.save();
                      if(formCurrentState!=null && formCurrentState.validate()){
                          print("Valid Data");
                      }
                      else{
                        print("Not Valid Data");
                      }
                  }, child: Text('Add Task'),
                  style: ButtonStyle(
                    
                    backgroundColor: MaterialStateProperty.all(Colors.deepOrangeAccent)),
                   ),
                ),
              ],
            ),
          )
        ],),),
    );
  }
}
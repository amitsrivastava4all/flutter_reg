// label loops
void main() {
  // outer loop
  OUTER: // this is a label of i loop
  for (int i = 1; i <= 3; i++) {
    // inner loop
    for (int j = 1; j <= 3; j++) {
      if (i == j) {
        continue OUTER; // skip the ith Iteration
        //break OUTER; // exit from the ith loop
        //break; // exit from the current loop
        //continue; // Skip the current Iteration
      }
      print("I is $i and J is $j");
    } // jth loop ends
  } //ith loop ends
  print("Program Ends");
}

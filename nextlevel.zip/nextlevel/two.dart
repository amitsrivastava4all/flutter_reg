import 'dart:io';

void main() {
  //int choice = 1;
  print("Enter Your Choice ");
  int choice = int.parse(stdin.readLineSync().toString());
  switch (choice) {
    case 1:
      print("Pizza");
      // return; // exit from a function
      //break; // exit from a switch block
      continue DRINKS;
    case 2:
      print("Dessert");
      break;
    //break;
    DRINKS: // this is a label
    default:
      print("Drinks");
  } // switch case ends
  print("Bye Bye Customer");
}

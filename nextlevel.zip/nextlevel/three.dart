//Loops
void main() {
  // Sequential Loop
  /*for (int i = 1; i <= 10; i++) {
    print("I is $i");
  }*/
  /*int i = 1;
  while (i <= 10) { // First Condition Check then go in Iteration
    print("I is $i");
    if (i >= 5) {
      i += 2;
    } else {
      i++;
    }
  }*/
  int i = 20;
  do {
    // First Iteration and then Condition Check
    print("I is $i");
    i++;
  } while (i <= 10);
  List<int> prices = [100, 200, 300, 500, 888];
  // old style
  /* for (int i = 0; i < prices.length; i++) {
    print(prices[i]);
  }*/
  // for in loop
  for (int price in prices) {
    print(price);
  }
}

import 'dart:io';

void main() {
  print("Enter the First Number");
  int firstNumber = int.parse(stdin.readLineSync().toString());
  print("Enter the Second Number");
  int secondNumber = int.parse(stdin.readLineSync().toString());
  // if(1){

  // }
  // if(true){

  // }
  // else{ // false

  // }
  print(firstNumber > secondNumber
      ? "First Number is Greater"
      : "Second Number is Greater");
  // if (firstNumber > secondNumber) {
  //   print("First Number is Greater");
  // } else {
  //   print("Second Number is Greater");
  // }
}

//Anonymous Function
final mul = (int x, int y) {
  return x * y;
};
Function fn(Function fn1, Function fn2) {
  return () {};
}

//3rd way of define a function
// Fat Arrow Fn
final div = (int a, int b) => a / b;

// Normal function / Named Function
int add(int x, int y) {
  int z = 999;
  Function m = () {};
  // Statisically Type Function Defination
  return x + y;
}

// by default function return null
sub(a, b) {
  print(a - b);
}

addition(a, b) {
  // Dynamically typed function defination
  return a + b;
}

void main() {
  print("Divide ${div(10, 2)}");
  print("Multiply Result is ${mul(10, 2)}");
  int x = 100; // Variable expression/ value expression
  Function fn = () {
    // Function Expression / Anonymous Function
    // Write my logic
  };
  print(fn.runtimeType);
  var fn2 = () {};
  print(fn2.runtimeType);
  print(add(10, 20));
  print(addition(10.20, 90.20));
  print(addition(10, 20));
  print(addition(10, 90.20));
  print(addition("Amit", "Srivastava"));
  print(sub(10, 20));
  //print(add(10.20, 90.20));
}
